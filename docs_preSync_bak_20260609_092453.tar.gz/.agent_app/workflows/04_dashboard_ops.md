﻿# Workflow: Dashboard Operations

Current documentation refresh: 2026-04-29.

## Purpose

Operate the main dashboard views for AI process monitoring, review analytics, and operational reporting.

## Inputs

- `QR_codes.db`
- curated JSON payloads in `Output_jason_api/`
- Dashboard chart modules in `Dashboard/charts/`

## Main Steps

1. Open the dashboard application and load the requested operational page.
2. Use building and process filters to scope the analytics.
3. Review AI queue and summary tables derived from DB and JSON state.
4. Review the Operational Performance Analysis charts.
5. For data quality analytics, use the `All` / `Open Process` toggle in the chart header to control scope.
6. View FLS charts for FLS asset management visualization (requires Altair).
7. View the map chart for assets by building distribution.
8. View the SDI flow chart for flow quantity metrics.
9. Use the dictionary management UI to view or edit the mechanical dictionary.
10. Manage FLS assets through add, delete, bulk update, and read-only magnifying-glass detail views.

## Current Analytics Rules

- the operational data-quality view uses the merged `Data Quality Comparison` chart
- the chart compares weighted completeness and mean AI confidence by asset type on the same 0-100 scale
- completeness is recomputed from current JSON using discipline-aware rules, not stale fixed field counts
- AI confidence uses `Avg_ai_conf` first and falls back to normalized `confidence_scores` only when needed
- FLS charts use Altair for interactive visualization
- FLS New Device Flow hides Asset Group, Space, and Details in the main table; those fields remain available in Edit and magnifying-glass detail views
- FLS Control Panel Code/Description is derived from `"UBC - Asset Data Master Info"` using the selected building's property code
- if a building has multiple Control Panel rows, the lowest Code row is displayed and the row/form is flagged
- map chart shows assets distributed by building location
- SDI flow chart shows flow quantity analytics

## Outputs

- visual monitoring of AI throughput, review status, and data quality
- building-scoped and process-scoped analytics for operations
- FLS asset management operations
- dictionary updates

## Verification

- confirm building filters update the operational charts
- confirm `Open Process` excludes approved rows while `All` includes them
- confirm empty states render as valid chart images instead of broken icons
- confirm FLS charts render when Altair is available
- confirm FLS Control Panel Code/Description updates when Property changes in New/Edit forms
- confirm multi-match buildings show the first Control Panel row and a warning flag
- confirm hidden FLS table fields remain visible in Edit and magnifying-glass detail views
- confirm dictionary edits persist correctly

## Embedded Sub-App Tabs

The Dashboard now hosts ME, BF, EL, and SDI as in-page iframe tabs rather than launching them in a new browser tab. Each sub-app retains its own port, domain, and systemd service.

### Steps

1. Click `Launch App` on any of the four sub-app cards (Asset Reviewer Mechanical / Backflow / Electrical, or SDI Process). The Dashboard switches to a hash-routed view (`#review-me-view`, `#review-bf-view`, `#review-el-view`, `#sdi-view`) and the iframe loads `https://<sub-app>/?embedded=true` lazily on first activation.
2. Inside the embedded view, the sub-app's own top navbar / brand header / user dropdown is suppressed; functional controls (building selector, archive toggle, filters, meta-pills, approve toggle, sub-app's own back-to-list button) remain visible.
3. Use the `Dashboard` button in the central process-view-header (top of the embedded view) to return to the central main view. Use `Open full page` to open the sub-app standalone in a new browser tab.
4. Internal navigation inside the iframe (DataTable pagination, asset review drill-in, tab switching) preserves `?embedded=true` automatically.

### Verification

- confirm `Launch App` for `review_me`, `review_bf`, `review_el`, and `sdi_process` does not open a new browser tab.
- confirm the iframe loads only on first activation and does not reload when the user revisits the tab during the same session.
- confirm cookies on the sub-app domain show `SameSite=None; Secure; HttpOnly` (DevTools → Application → Cookies).
- confirm the sub-app's own login is not requested inside the iframe when the user is already logged into the Dashboard.
- confirm the `Dashboard` button in the process-view-header returns to the central main view without a full page reload.
- confirm the sub-app standalone URL (without `?embedded=true`) still renders its own navbar and chrome unchanged.
