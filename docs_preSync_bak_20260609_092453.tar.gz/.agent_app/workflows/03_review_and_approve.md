﻿# Workflow: Review and Approve

Current documentation refresh: 2026-05-27.

## Purpose

Allow human reviewers to correct extraction output, preserve curated fields, and push approved data into SDI staging tables.

## Inputs

- extraction JSON in `Output_jason_api/`
- review apps for ME, BF, and EL
- `QR_codes.db` curated dataset tables

## Main Steps

1. Open the correct review app for the discipline. (For Electrical, choose 'General' or 'Distribution' scope first on the landing page).
2. Let the `before_request` sync reconcile new JSON and image state into the DB.
3. Use the dashboard tabs to select New, Update (hidden in Electrical), or Manual Entry assets.
4. Open the review page, compare the JSON against the photos, and edit values as needed.
5. Save changes back to the JSON payload and mark the file `modified=true` when content changes.
6. Sync the curated record into `sdi_dataset` for ME/BF or `sdi_dataset_EL` for EL.
7. Toggle `Approved` when the record is ready for downstream packaging.

## Current Review Rules

- approval must not wipe `Asset Group`, `Attribute`, `Description`, or other curated dictionary fields
- review-page photos can be inspected with the shared image viewer: wheel zoom, drag pan, zoom/rotate/reset buttons, double-click detail/reset, and keyboard shortcuts
- ME/BF/EL review dashboards expose `Avg AI Conf` and confidence slicers
- Manual Entry is not only a visual tab; it must align `Col_process = 2`, JSON `ExcludeSDI`, and `QR_codes.sdi = 1`
- confidence filters and display values must stay aligned between backend and frontend
- the dashboard Photo column shows the required-photo ratio (`{present}/{required}`) inside the red/green pill, plus a small `+1` chip when the optional **Extra Photo** is present (ME `-4`, BF `-3`, EL `-3`); the chip is informational only, its absence never sets "Missed Photo", and the Photo value cell is left-aligned in New / Update / Manual listing tables
- the single-asset review page exposes the Extra Photo as a labeled "Extra Photo" thumbnail in the strip; an absent Extra Photo renders the neutral "Missing" placeholder with no red/error styling

## Outputs

- updated JSON payloads
- updated curated dataset rows in `QR_codes.db`
- approved rows ready for SDI Process unless explicitly excluded from SDI

## Verification

- confirm review-page edits persist after reload
- confirm source-photo inspection works in standalone and Dashboard iframe views: wheel zoom, drag pan, rotate, reset, thumbnail reset, and keyboard shortcuts
- confirm dashboard filters survive save / next / previous navigation
- confirm approved rows appear in the correct curated dataset table
- confirm manual-entry assets do not leak into SDI packaging when excluded

## Bulk Manual / Approved actions (ME + BF + EL)

The ME, BF, and EL review dashboards expose a master checkbox in the **Manual** and **Approved** column headers of every tab table (New / Update / Manual). BF and EL use the same client-side batching pattern as ME.

### Steps

1. Filter or paginate the tab table to the rows you want to act on. The bulk action only touches DataTables-visible rows.
2. Click the master Manual or Approved checkbox in the column header.
3. Confirm the action in the `#confirmModal` dialog, or in the `window.confirm()` fallback if the modal is unavailable. Cancelling reverts the checkbox. The `#confirmModal` uses `modal-dialog-centered`, so the dialog is vertically centered and not clipped by the Dashboard top bar when the review app is embedded.
4. The dashboard fans out per-row calls to `POST /toggle_sdi/<doc_id>` or `POST /toggle_approved/<doc_id>` in a client-side queue and re-renders affected cells in place.

### Client-side filters

- **Bulk-Manual** skips rows where Approved is already `True` — Manual-flagging an approved row is not allowed.
- **Bulk-Approved un-check** first calls `GET /check_sdi/<qr_code>` and skips exported / Planon-locked rows.
- Rows where the current value already matches the target are skipped silently (no-op).
- BF only renders the header checkboxes when `can_edit` is true. EL keeps the existing endpoint-enforced permission behavior.

### Verification

- confirm canceling the modal leaves all rows unchanged.
- confirm filter scope is respected — hidden rows are never modified.
- confirm Approved uncheck with an exported row leaves that row unchanged.
- confirm row cells update in place and the current DataTable redraws after the queue drains.

## EL Distribution listing view

The "Review Electrical Assets - Distribution" dashboard keeps the same data model as the general EL dashboard but hides three listing-table columns for scanability: **Amperage Rating**, **Volts**, and **Location**. The hide is frontend-only and scoped to `/review-distribution`; `review.html`, `/review-all`, JSON, DB rows, SDI packaging, and Planon export still carry the fields.

The EL dashboard also loads the shared `_shell.html` partial so the standalone sidebar/topbar behavior matches ME and BF. Required-field checklist popovers use a higher `.el-required-popover` z-index than the shell sidebar so QR hover cards render above the shell.

## EL Single Line Diagram (SLD) Panel

The EL Distribution view has a dedicated SLD panel (`sld_blueprint.py`, `sld_panel.html`, `sld.js`) that operates on `electrical_building_schema` (the diagram-side table) alongside the matched `sdi_dataset_EL` row.

### Inline editor (Swift Over)

The panel renders rows in an editable table. Each row's Save button posts to `POST /sld/api/assets/<row_id>/swift-save`, which:

1. Updates `electrical_building_schema` for the row in a single local transaction.
2. If the row has a matched `sdi_dataset_EL` entry (`matched_qr` present), merges the patch into `<QR>_EL_<Building>.json` under `json_sync_lock`, then calls `_sync_db_from_structured` to upsert `sdi_dataset_EL`.
3. Recomputes `matching_check` and returns the enriched row for client-side row replacement.

Failures inside the JSON / SDI sync trigger a rollback of both the SLD update and the JSON write.

### Reconciliation column

The rightmost column (header **Reconciliation**, previously "Check") flags whether the SLD row and its `sdi_dataset_EL` counterpart agree on the composite key `Building | Equipment ID/UBC Asset Tag | Supply From`. The status comes from `id_check_match`, a boolean computed by `_enrich_asset_display_fields` from each table's `ID_check` column.

- **Green ✓** — both sides match.
- **Red ✗ (clickable)** — the two sides disagree but a matching QR exists; clicking opens the Reconcile modal (see below).
- **Red ✗ (static)** — no matching SDI row for this SLD entry at all (no reconciliation possible from this UI).

`ID_check` is a `GENERATED ALWAYS AS (TRIM(COALESCE(Building,'')) || ' | ' || TRIM(COALESCE("Equipment ID"|"UBC Asset Tag",'')) || ' | ' || TRIM(COALESCE("Supply From",''))) VIRTUAL` column on both `electrical_building_schema` and `sdi_dataset_EL`. Do not write to it from Python — the DB rejects the write and the column tracks `Building` / `Equipment ID` / `Supply From` automatically.

### Reconcile modal flow

Clicking a red Reconciliation cell on a QR-matched row opens a modal with three choices:

- **Diagram is correct** — write the SLD's `Supply From` to `sdi_dataset_EL` + the JSON file.
- **Captured asset is correct** — write `sdi_dataset_EL`'s `Supply From` back to `electrical_building_schema`.
- **Custom** — write a user-entered value to both sides.

Submission posts to `POST /sld/api/assets/<row_id>/reconcile` with `{choice, value?, reason?}`. The endpoint:

1. Resolves the SLD active row + matching SDI row.
2. Updates each side only if its current value differs from the target.
3. Writes one `audit_trail` row per changed side (`table_name="electrical_building_schema"` or `"sdi_dataset_EL"`, `source="human"`, `description="reconcile:<choice>"` plus the optional reason).
4. Rolls back atomically on JSON or SDI failure (SLD update restored, JSON file restored from backup).
5. Returns the updated enriched row for in-place client refresh.

Idempotent: a second call with the same target value returns `{status: "noop"}`.

### Orphan JSON case

`swift_save_asset` (and `reconcile_asset`) require the matched SDI row's JSON file to exist on disk at `Output_jason_api/<QR>_EL_<Building>.json`. If the JSON is missing while the SDI row is present, the request returns `500 {"error": "Failed to sync captured asset: JSON not found for QR ..."}`. Either restore the JSON or remove the orphaned SDI row.

## Update 2026-06-01 — archive-aware listing and approval UI

- **SLD building dropdown** (EL Distribution) lists only buildings with at least one displayable (non-archived) QR; fully-archived buildings drop off. Hidden escape hatch: `GET /sld/api/buildings?include_archived=true`.
- **Archive toggle / filters**: the "Show/Hide Archive" label is now action-correct, and the Review Status filter and archive button preserve each other's query params, so an "Approved + Show Archive" view holds across reloads (EL/ME/BF).
- **Bulk Approve** (EL "approve all") now reports failures in a modal rather than silently doing nothing.
- **Flow integrity**: `scripts/audit_sdi_flow_integrity.py` detects assets that cannot complete approve→package→archive (e.g., approved but SDI-excluded, or a cross-store approval mismatch); remediate per `special_processes/sdi_flow_remediation.md`. Approval is consumed/regenerated by re-capture + the nightly rebuild, so an archived asset can read `Approved=blank` in the live row while its prior approval persists in the archived package (`id_print_out`).
