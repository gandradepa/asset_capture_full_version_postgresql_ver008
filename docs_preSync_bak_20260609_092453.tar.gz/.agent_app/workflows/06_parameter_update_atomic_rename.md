﻿# Workflow: Parameter Update and Atomic Rename

Current documentation refresh: 2026-04-28.

## Purpose

Convert temporary QR identities into final parameterized identities without leaving the platform in a split state.

## Inputs

- temporary QR code and target permanent QR code
- related JSON payload, image files, DB rows, and processed logs

## Main Steps

1. Validate that the source QR is temporary and the target QR is valid and unused.
2. Compute the full rename set across images, JSON, processed logs, and DB tables.
3. Apply the rename as one logical operation.
4. If any step fails, roll back the already-applied pieces.
5. Rebuild any cached or derived state that depends on the QR code.

## Assets That Must Stay Aligned

- `Capture_photos_upload/*.jpg`
- `Output_jason_api/*.json`
- processed log files and automation traces
- `QR_codes` and `QR_code_assets`
- curated SDI dataset rows if they already exist

## Guardrails

- do not run ad-hoc partial renames
- preserve building and asset-type identity during the rename
- verify review navigation and SDI state still resolve against the renamed QR

## Verification

- confirm there are no leftover files under the old QR code
- confirm database rows exist only under the new QR code
- confirm review, dashboard, and SDI pages resolve the asset correctly after rename
