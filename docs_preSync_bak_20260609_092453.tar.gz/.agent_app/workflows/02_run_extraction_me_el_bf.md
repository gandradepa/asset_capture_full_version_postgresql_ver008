# Workflow: Run Extraction for ME, EL, and BF

Current documentation refresh: 2026-05-25.

## Purpose

Process captured images into discipline-specific JSON payloads and sync summary state into the database.

## Inputs

- images in `Capture_photos_upload/`
- current extraction scripts in `API/`
- `asset_capture_app_dev/data/QR_codes.db`

## Main Steps

1. Run the extraction worker for the target discipline or the full extraction chain.
   - **Recommended**: Use `run_ai_and_sync.sh`, which chains AI extraction to DB sync automatically.
   - The separate manual `update_db` task has been removed from the Dashboard launcher.
2. Discover candidate assets from the image filenames.
3. Read the sequence-specific photos for each QR.
4. Apply OCR and LLM extraction.
5. Normalize the response into the discipline schema using shared validators (`validators_shared.py`).
6. Apply completeness and confidence rules before writing the final JSON.
7. Write the payload to `Output_jason_api/<QR>_<TYPE>_<Building>.json`.
8. DB sync runs automatically (via chained script) to update `json_files`, `sdi_dataset`, and `sdi_dataset_EL` as appropriate.

## Discipline Rules

- ME completeness: `Manufacturer`, `Model`, `Serial Number`, `Year`, `UBC Tag`, plus `Technical Safety BC` only when seq `-3` exists.
- BF completeness: `Manufacturer`, `Model`, `Serial Number`, `Diameter`.
- EL completeness: `UBC Asset Tag`, `Ampere`, `Supply From`.
- EL confidence averages exclude `Volts`, `Location`, and `Branch Panel`.
- ME confidence includes `Technical Safety BC` only when seq `-3` exists.
- Optional **Extra Photo** sequences (ME `-4`, BF `-3`, EL `-3`) are excluded from each pipeline's `VALID_SUFFIXES` and never reach the LLM. The pipeline's `FILENAME_PATTERN` regex was widened (ME `[0-4]`, BF `[0-3]`, EL `[0-3]`) so discovery sees the file and logs it as `invalid_seq` rather than `name_mismatch`, but the file is not added to `info["images"]`.

## Outputs

- JSON payloads in `Output_jason_api/`
- synced rows in `json_files`
- updated AI status and curated dataset rows in `QR_codes.db`

## Verification

- confirm each JSON has the expected top-level keys and discipline fields
- confirm blank fields do not retain non-zero confidence
- confirm `Avg_ai_conf` and `completeness_score` follow the current discipline rules
- confirm database sync completes without duplicate or placeholder QR rows
