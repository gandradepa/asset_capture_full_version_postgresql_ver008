﻿# Workflow: Capture to JSON

Current documentation refresh: 2026-05-25.

## Purpose

Capture photos, create or update QR identity records, and leave a clean input set for extraction.

## Inputs

- user session in `asset_capture_app_dev`
- building, asset type, and location context
- one or more captured photos per asset sequence

## Main Steps

1. Launch the capture app and authenticate.
2. Start a capture session for the selected building and asset type.
3. Capture the required photos plus, optionally, an **Extra Photo** (sequence `-4` for ME, `-3` for BF/EL). The Extra Photo tile is rendered with `data-optional="true"` and is excluded from the "all required captured" check.
4. Save photos into `Capture_photos_upload/` using the `<QR> <Building> <Type> - <Seq>.jpg` pattern. `save_image_file()` applies `ImageOps.exif_transpose()` before writing, so phone photos with an EXIF Orientation tag are physically rotated to portrait on disk.
5. Upsert `QR_codes` with the QR-level state and location context.
6. Upsert `QR_code_assets` with the per-photo `code_assets` rows.
7. If the QR is temporary, keep the temporary code until the atomic rename workflow runs.

## Outputs

- normalized image set in `Capture_photos_upload/`
- `QR_codes.db` rows in `QR_codes` and `QR_code_assets`
- elapsed-time JSON (`_et.json`) in `Output_jason_api/`
- a complete extraction input set for ME, BF, or EL

## Guardrails

- reject placeholder QR IDs such as `None`, `nan`, or blank strings
- keep QR identity unique after normalization
- do not partially rename files or DB rows outside the atomic rename workflow
- keep `QR_codes` and `QR_code_assets` aligned on the same QR and building context
- `QR_code_assets` rows must include `user` and `date_hour` audit columns

## Verification

- confirm images exist for the intended QR and sequence numbers
- if an Extra Photo was captured, confirm the corresponding `-4` (ME) or `-3` (BF/EL) file is present and is excluded from any AI/extraction logging
- confirm `QR_codes` has the expected building, type, location, and `sdi` default
- confirm `QR_code_assets` has the expected `code_assets` rows, process assignment, `user`, and `date_hour`
- confirm elapsed-time JSON exists with correct `qr_code`, `building_number`, `asset_type`, and `elapsetime`
- confirm a freshly captured portrait photo is stored portrait-side-up on disk (open with any image viewer, or check `exiftool` reports `Image Size: W×H` with `H > W` and no `Orientation` tag)
