﻿# Asset Extraction API Agent

Current documentation refresh: 2026-05-27.
## Purpose
Analyze industrial images with Tesseract OCR (contextual enrichment) and OpenAI GPT-4o Vision to extract normalized equipment configurations.
## Scope
**In-scope**: Execution paths for ME (`API_interface_ME_ver00.py`), EL, and BF extraction. Utilizing the Hybrid OCR strategy. Synchronizing parsed output JSON to the operational DB (PostgreSQL `qr_code_db`, via `db.py`; SQLite `QR_codes.db` is the frozen rollback).
**Out-of-scope**: End-user API routes.
## Inputs
Image files from `Capture_photos_upload/` matching `<QR> <Building> <TYPE> - <SEQ>.jpg`.
## Outputs
A JSON file inserted natively into `Output_jason_api/`: `<QR>_<TYPE>_<Building>.json`.
SQL updates pushed dynamically to the operational DB — PostgreSQL `qr_code_db` (VM `127.0.0.1:5433`) via `db.py`; legacy SQLite `QR_codes.db` is the frozen rollback.
## Dependencies
- `validators_shared.py` (Must use for Manufacturer, Model, Serial, UBC Tag normalization).
## Key Paths & Env Vars
- `OPENAI_API_KEY`
- `ME_OCR_MODE` / `BF_OCR_MODE`
## Critical Conventions
- Uses the `AssetProcessor` OOP architecture. 
- Completeness Guard enabled: Only overwrite output if `new score >= existing score`.
- EL stale JSON guard: if `_existing_el_output_needs_rescore()` flags an existing payload, the processor must continue extraction even when `EL_OVERWRITE_EXISTING_JSON=false`; otherwise stale rows can loop back to `ai_status=0`.
- Approved EL rows are SDI-locked and excluded from AI reprocessing, so the stale detector must not reset their `ai_status=1` flag.
- Human-reviewed EL JSON (`modified=true` or manual override flags) is not AI-refreshable unless an explicit migration/reprocessing task says otherwise.
- Support Windows/Linux `tesseract` binary targeting.
- Implement the Halucination Defense via targeted string negatives for ME module.
## Common Tasks
1. Execute EL extraction via `run_ai_and_sync.sh run_el`.
2. Sync `.json` datasets to the operational DB (PostgreSQL `qr_code_db`, via `db.py`) using `updating_process_database.py`.
## Failure Modes & Safeguards
- Handles `RateLimitError` gracefully via `API_MAX_RETRIES`. Threads bound to `MAX_WORKERS=8`.
## Validation Checklist
- [ ] `AssetProcessor` class structure exists.
- [ ] `extra="forbid"` utilized on Pydantic extractions.
- [ ] Each pipeline keeps the optional **Extra Photo** sequence (ME `-4`, BF `-3`, EL `-3`) out of `VALID_SUFFIXES`, so it is discovered + logged but never sent to the LLM. The widened `FILENAME_PATTERN` only controls discovery logging, not LLM eligibility.
