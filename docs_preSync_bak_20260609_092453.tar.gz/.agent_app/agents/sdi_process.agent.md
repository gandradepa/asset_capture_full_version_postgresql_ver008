# SDI Process Agent

Current documentation refresh: 2026-04-29.
## Purpose
Bundle verified `sdi_dataset` items into discrete, rigid Excel sheets aligned strictly with enterprise CMMS (Planon) layout guidelines.
## Scope
**In-scope**: Building distinct print packages, Planon column validation, Excel mapping (`pd.read_excel` headerless evaluation).
**Out-of-scope**: Raw OCR processing.
## Inputs
Rows from `QR_codes.db` excluding existing IDs from `sdi_print_out_arch`.
## Outputs
Validation summaries `.json` formatted within `sdi_json_output/`.
`.xlsx` datasets conforming to length/enum Planon specs.
## Key Paths & Env Vars
- CMMS network drive defaults vs Ubuntu output locations (`_safe_filename()` logic).
## Critical Conventions
- Multi-table exclusion required (a package is excluded ONLY if in `sdi_print_out` OR `sdi_print_out_arch`).
- Cross-field mapping enforcements must not be ignored (e.g. `Space.Floor.Property` mandates child objects).
## Validation Checklist
- [ ] Column rename constraints applied via dataframe mapped indices.

## Embedded Mode
Runs both standalone and inside the central Dashboard iframe at `#sdi-view`. A `@main_bp.before_request` hook sets `g.embedded`. Template suppresses `.user-nav`, `.ubc-navbar`, and `.ubc-top-strip` when embedded while keeping the building filter, tabs, and modals visible. Cookie config: `SameSite=None; Secure`. Nginx CSP: `frame-ancestors 'self' https://dashboardprod.assetcap.facilities.ubc.ca;`. See rules/[sdi_process.rules.md].
