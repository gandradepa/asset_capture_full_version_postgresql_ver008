﻿# Dashboard Agent

Current documentation refresh: 2026-05-14.

## Purpose
Provide the analytics and launch surface for the platform as a Flask single-page application.

## Scope
- In scope: aggregated telemetry, chart rendering, readiness views, FLS CRUD, and task launching.
- Out of scope: direct review-form editing and image-based QA.

## Inputs
- Shared database tables such as `QR_codes`, `sdi_dataset`, `sdi_dataset_EL`, and related telemetry tables.

## Outputs
- Rendered dashboard views
- Chart PNG responses
- Operational counts based on persisted review and SDI state

## Critical Conventions
- Keep the SPA view model based on `showView(...)`.
- Chart modules must degrade gracefully if optional dependencies are unavailable.
- Approval and readiness metrics must use persisted review-app state, not client-only row updates.

## Validation Checklist
- [ ] Matplotlib figures are closed correctly.
- [ ] Optional chart failures do not break the whole dashboard.
- [ ] Approval and readiness views reflect saved state from the review pipeline.

## Unified Shell
Dashboard hosts ME / BF / EL / SDI as embedded iframe panels (`#review-me-view`, `#review-bf-view`, `#review-el-view`, `#sdi-view`). Each iframe loads `<sub-app>/?embedded=true` lazily on first activation via `IFRAME_VIEW_MAP` and `maybeLoadIframe()`. `<main>` switches to `.container-iframe-view` (full-width, edge-to-edge) for iframe tabs. Cross-subdomain session sharing requires `SameSite=None; Secure` cookies. Nginx sets `frame-ancestors 'none'` for the Dashboard. Full rules in `rules/dashboard.rules.md`.

## SLD Extraction Logs
`System Logs → SLD Extraction Runs` surfaces every SLD extraction run as a structured row. The Dashboard reads `/home/developer/sld_extract_feedback/sld_*.jsonl` directly (no DB table for runs).
- `GET /sld-logs/runs` — JSON list (in-page Refresh button)
- `GET /sld-logs/runs/<run_id>` — drilldown: run summary + DB asset rows + model_call telemetry
- `POST /sld-logs/runs/<run_id>/rerun` — admin-only proxy to EL Reviewer's `POST /sld/api/rerun/<run_id>` (forwards session cookie via stdlib `urllib`, no CORS).
Admin gate: `DASHBOARD_ADMIN_USERS` env var from `auth_service.env` — the single source of truth shared with EL Reviewer.
