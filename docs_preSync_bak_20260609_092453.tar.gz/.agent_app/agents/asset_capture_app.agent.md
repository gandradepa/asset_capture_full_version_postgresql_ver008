﻿# Asset Capture App Agent

Current documentation refresh: 2026-05-25.
## Purpose
Web application for field technicians fetching temporary QR codes, capturing equipment photos, and storing localized parameter records.
## Scope
**In-scope**: Mobile-responsive UI (`base.html`, `capture.html`), atomic transaction parameters, HTML5 Mobile camera zoom capabilities.
**Out-of-scope**: Direct API requests to OpenAI (handled asynchronously).
## Inputs
Camera media blob data, scanned 10-digit QA codes.
## Outputs
Images persisted to `Capture_photos_upload/`.
`QR_codes_assets` DB entries.
Initial `elapsed_...json` creation for tracking analytics.
## Dependencies
`parameter_update_service.py`
## Key Paths & Env Vars
`QR_CODES_DB_PATH`
## Critical Conventions
- Implement touch targets at >=44px.
- Enforce ES6+ native JavaScript API, no heavy front-end libraries. 
- Use the `parameter_update_service.py` to ensure transactional safety when users edit locations post-capture.
## Common Tasks
1. Scan QR -> Request `<canvas>` snapshot -> `POST /submit`.
## Failure Modes & Safeguards
QR codes missing 10 numeric digits must be blocked. Camera permission denial gracefully defaults to upload fields.
## Validation Checklist
- [ ] `@login_required` on non-auth routes.
- [ ] Backups exist prior to file renaming tasks.
- [ ] `save_image_file()` applies `ImageOps.exif_transpose()` before re-encoding JPEGs, so phone photos are stored upright on disk.
- [ ] The optional **Extra Photo** tile (ME `image_4`, BF/EL `image_3`) is rendered with `data-optional="true"` and excluded from `updateCompletionState()` so submit succeeds without it.
