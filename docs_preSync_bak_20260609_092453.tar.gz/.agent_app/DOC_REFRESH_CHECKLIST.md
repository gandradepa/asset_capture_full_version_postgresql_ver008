# Documentation Refresh Checklist

Last refresh pass: 2026-06-03.

Tracked refresh for project-authored markdown documentation.

## Scope Rules

- Include root docs, root `rules/`, root `workflows/`, root `special_processes/`, root `skills/`, and service-local `.agent` docs.
- Exclude `venv/`, `site-packages/`, and third-party license markdowns.
- Treat root docs and service-local docs as canonical.
- Update `.agent_app/` mirrors only after canonical docs are finished.

## P0

- [x] `README.md`
- [x] `00_README.md`
- [x] `01_GLOBAL_RULES.md`
- [x] `02_SYSTEM_MAP.md`
- [x] `03_ARCHITECTURE_MAP.md`
- [x] `rules/asset_capture_app.rules.md`
- [x] `rules/asset_dictionary.rules.md`
- [x] `rules/asset_extraction_api.rules.md`
- [x] `rules/dashboard.rules.md`
- [x] `rules/review_apps.rules.md`
- [x] `rules/sdi_process.rules.md`
- [x] `special_processes/01_atomic_rename_operations.md`
- [x] `special_processes/02_completeness_guard.md`
- [x] `special_processes/03_dictionary_ast_parsing.md`
- [x] `special_processes/04_database_topography.md`

## P1

- [x] `workflows/01_capture_to_json.md`
- [x] `workflows/02_run_extraction_me_el_bf.md`
- [x] `workflows/03_review_and_approve.md`
- [x] `workflows/04_dashboard_ops.md`
- [x] `workflows/05_sdi_packaging_and_planon_export.md`
- [x] `workflows/06_parameter_update_atomic_rename.md`
- [x] `design/DESIGN.md`
- [x] `design/PRODUCT.md`
- [x] `skills/ubc_asset_platform/SKILL.md`
- [x] `schemas/response_schema_notes.md`
- [x] `API/.agent/api_comparison_matrix.md`
- [x] `Dashboard/.agent/api_comparison_matrix.md`
- [x] `asset_capture_app_dev/.agent/QR_codes_db_schema.md`

## P1 Service-Local Canonical Docs

- [x] `asset_capture_app_dev/.agent/*`
- [x] `API/.agent/*`
- [x] `Dashboard/.agent/*`
- [x] `review/.agent/*`
- [x] `SDI_process/.agent/*`
- [x] `dictionary/.agent_dictionary/*`
- [x] `auth_service/.auth_agent/*`

## P2 Mirror and Long-Form Docs

- [x] `.agent_app/00_README.md`
- [x] `.agent_app/01_GLOBAL_RULES.md`
- [x] `.agent_app/02_SYSTEM_MAP.md`
- [x] `.agent_app/rules/*`
- [x] `.agent_app/special_processes/*`
- [x] `.agent_app/workflows/*`
- [x] `.agent_app/skills/*`
- [x] `.agent_app/schemas/*`
- [x] `.agent_app/agents/*`
- [x] `.agent_app/UBC_Asset_Capture_Application_Documentation.md`
- [x] `.agent_app/UBC_Asset_Technical_Documentation.md`
- [x] `UBC_Asset_Capture_Application_Documentation.md`
- [x] `UBC_Asset_Technical_Documentation.md`
- [x] `assetcap_setup_manual.md`

## Current Refresh Themes

- discipline-specific completeness and AI-confidence rules
- `Avg_ai_conf` handling in review, dashboard, and DB sync
- merged `Data Quality Comparison` chart
- review dashboard confidence slicer behavior
- SDI duplicate-row prevention and normalized QR joins
- Manual Entry versus SDI exclusion synchronization
- approved-row flow into SDI staging
- FLS charts (Altair-based), FLS asset CRUD with `new_device` table, and FLS Control Panel lookup from `"UBC - Asset Data Master Info"`
- Dashboard dictionary management UI with AST-safe parsing
- Map chart and SDI flow chart additions
- Chained AI+DB sync via `run_ai_and_sync.sh` (removed manual `update_db` task)
- Planon export with UBC tag parsing and year formatting
- Validation log viewer in SDI Process
- Package archive management (active/archive/exclude)
- User and timestamp tracking in `QR_code_assets`
- Elapsed-time JSON artifacts in capture workflow
- Photo viewing API in Dashboard
- Parameter update service (`parameter_update_service.py`) in Capture App
- Shared validators (`validators_shared.py`) in extraction API
- Root and setup README files were corrected for current service targets and ASCII-safe formatting.
- Unified Dashboard shell embedding ME / BF / EL / SDI as iframe panels with `?embedded=true`, cross-subdomain `SameSite=None; Secure` cookies, Nginx `frame-ancestors` CSP, and central postMessage / hash-route navigation.
- Optional **Extra Photo** capture slot added to ME (`-4`), BF (`-3`), and EL (`-3`). Visible in capture and review but excluded from `VALID_SUFFIXES`, completeness, AI confidence, and "Missed Photo"; renders as a `+1` chip in dashboard Photo columns.
- EXIF Orientation transpose applied in `save_image_file()` so phone photos with an EXIF Orientation tag are physically rotated to portrait on disk. No backfill of historical files.
- BF and EL review dashboards now match ME-style Manual / Approved header bulk toggles, scoped to filtered DataTables rows and using existing per-row endpoints.
- EL Distribution listing hides Amperage Rating, Volts, and Location only in the dashboard table; `review.html` and all backend/export data remain complete.
- EL dashboard standalone shell behavior now matches ME/BF, and required-field popovers are layered above the shared shell sidebar.
- Review-app modals (`#confirmModal` / `#infoModal` / `#planonModal`) and the Dashboard dictionary `#deleteModal` switched to `modal-dialog-centered` so dialogs render vertically centered instead of clipped by the embedded Dashboard top bar.
- EL SLD building dropdown (`get_buildings()` / `GET /sld/api/buildings`, `sld_blueprint.py`) lists only buildings with at least one displayable (non-archived) QR code; a building is hidden only when it has QR codes and all of them are in `sdi_print_out_arch`. Hidden escape hatch `?include_archived=true` returns the unfiltered list (2026-06-01).
- Review-app archive toggle label corrected (was inverted) — reads "Show Archive" when archived rows are hidden and "Hide Archive" when shown. The Review Status filter and the archive button now preserve each other's query params (`archive`, `approved`), so "Approved + Show Archive" can be active together; previously each control reset the other on reload (EL/ME/BF, 2026-06-01).
- EL bulk "Approve all" (`select-all-approved`) surfaces per-row failures (auth/session/server) in a summary modal instead of silently swallowing them (2026-06-01).
- Dashboard and SDI self-service password-change routes now use `User.set_password()` and update `password_hash`; incident note added at `Markdowns_documentation/INCIDENT_2026-06-03_password_change_persistence.md` (2026-06-03).
- New read-only `scripts/audit_sdi_flow_integrity.py` audits the approve→package→archive flow: exclusion-pair consistency (`QR_codes.sdi=1` ⇔ `QR_code_assets.Col_process=2`), approved-but-unarchivable worklist, cross-store approval mismatch, and blank-identity. Companion runbook `special_processes/sdi_flow_remediation.md` documents case-by-case remediation via app endpoints (`/toggle_sdi`, `/toggle_approved`, `/review`) — never raw DB/JSON edits (2026-06-01).
