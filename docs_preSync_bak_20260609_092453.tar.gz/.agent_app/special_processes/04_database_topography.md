﻿# Database Topography and Relationships

> **🐘 Database backend: PostgreSQL (C4 cutover complete, 2026-06-08).** The platform now runs on PostgreSQL (`qr_code_db`, VM `127.0.0.1:5433`) via a backend-agnostic `db.py` layer, switched by `DB_BACKEND=postgres` in `/home/developer/db_backend.env`. The SQLite `QR_codes.db` referenced throughout is now the **frozen rollback** (flip the env back to `sqlite` + restart to revert). See `Markdowns_documentation/special_processes/04_database_topography.md`, `C4_CUTOVER_RUNBOOK.md`, and the `pg-cutover-complete` memory.

Current documentation refresh: 2026-06-03.

## Overview

Operational workflow state is held in **PostgreSQL `qr_code_db`** (VM `127.0.0.1:5433`, via `db.py` / `DB_BACKEND=postgres`) as of the 2026-06-08 cutover; the legacy SQLite `asset_capture_app_dev/data/QR_codes.db` is now the frozen rollback, not the live store. Authentication/user state remains in its own SQLite database (`User_control.db`), unchanged by the cutover.

- PostgreSQL `qr_code_db` (VM `127.0.0.1:5433`)
  operational workflow state (live)
- `asset_capture_app_dev/data/QR_codes.db` (SQLite)
  frozen rollback — identical table/column model
- `User_control.db` (SQLite)
  authentication and user state (unchanged by the cutover)

## `QR_codes.db` Core Tables

### `QR_codes`

QR-level state, including:

- `QR_code_ID`
- approval state
- AI status
- SDI exclusion state (`sdi`)
- location and space context

### `QR_code_assets`

Process-placement and capture-tracking state, including:

- `code_assets`
- `Col_process`
- user / timestamp context

### `sdi_dataset`

Curated ME and BF records for approved assets.

Important columns include:

- `QR Code`
- `Building`
- curated asset fields
- `Approved`
- `Flagged`
- `Avg_ai_conf`

### `sdi_dataset_EL`

Curated EL records for approved assets.

Note: `ID_check` is a `GENERATED ALWAYS AS (...) VIRTUAL` column derived from `Building | UBC Asset Tag | Supply From`. Do not write to it from Python — the DB rejects the write. The column is used to detect divergence against `electrical_building_schema.ID_check` (see below) and surface the result in the SLD panel's Reconciliation column.

### `electrical_building_schema`

Diagram-side table for Electrical Distribution. Each row represents a node parsed out of a building's Single Line Diagram PDF by the SLD extraction pipeline. Active rows have `new_draw = "TRUE"`; superseded rows (replaced by a re-extraction) are archived in-place with `new_draw = "FALSE"`.

Important columns include:

- `row_id` (PRIMARY KEY)
- `Building`, `Equipment ID`, `Supply From` (and the wider Voltage / Amperage / Power / Wire Rating pairs)
- `new_draw` — "TRUE" for the currently-displayed extraction, "FALSE" for archived
- `ID_check` — `GENERATED ALWAYS AS (TRIM(COALESCE("Building",'')) || ' | ' || TRIM(COALESCE("Equipment ID",'')) || ' | ' || TRIM(COALESCE("Supply From",''))) VIRTUAL`. Mirrors the same expression used on `sdi_dataset_EL`; matching the two strings is how the EL Review SLD panel decides whether the diagram and the captured asset agree.
- `sld_extract_run_id`, `sld_ai_extract_payload` — feedback-corpus join keys (the run that produced the row, and a JSON snapshot of the AI-output fields for diff vs human correction)
- `matching_check` — derived flag refreshed by `recompute_matching_check`

Reconciliation between this table and `sdi_dataset_EL` is the responsibility of the EL Review SLD panel; the Reconcile endpoint (`POST /sld/api/assets/<row_id>/reconcile`) writes both sides atomically when a reviewer resolves a `Supply From` divergence.

### `sdi_print_out`

Active SDI package staging.

### `sdi_print_out_arch`

Archived SDI packages.

### Supporting Tables

- `json_files`
- `process_type`
- `Buildings`
- sequence / lookup tables used by SDI export or dashboard features

### `Asset_System_info` and Asset Master Lookup

`Asset_System_info` is a view, not a base table. It joins:

- `"UBC - Asset Data Master Info"` as `master`
- `"SUST - System List"` as `system`

The view's `"Code"` column is sourced from `"UBC - Asset Data Master Info"."Code"`. As of the 2026-06-03 VM migration, that source column is `TEXT` and every non-null value is stored as a 10-character zero-padded code, for example `0000054137` and `0000154409`.

Historical `QR_codes*.db` backup files may still show `"Code"` as numeric/integer without leading zeros. Do not use those backup files to validate current production state.

## Relationship Notes

- Review apps sync JSON corrections into the SDI dataset tables.
- SDI Process reads the curated SDI tables, not raw extraction JSON, for package staging.
- Manual Entry and SDI exclusion rely on QR-level state in `QR_codes` plus process state in `QR_code_assets`.

## Current Integrity Rules

- valid QR IDs should be unique after normalization
- placeholder QR IDs must not be treated as real assets
- `Col_process = 2` and `sdi = 1` should stay aligned for manual / excluded assets

## Architectural Caution

The schema is operationally shared across many modules, but not every module uses the same subset of tables. Changes to QR identity, approval, SDI state, or curated field schemas have platform-wide impact.
