﻿# Capture App Rules

Current documentation refresh: 2026-05-25.

## Purpose

The capture app owns QR intake, image upload, initial metadata capture, and parameter-update entry points.

## Backend Rules

- Require `@login_required` on non-auth routes.
- Use `_open_db()` or the app's DB resolver rather than hardcoded paths.
- Use parameterized SQL only.
- Validate missing input before building any QR or asset payload.
- Never convert missing values into placeholder strings such as `None`, `nan`, or `null`.

## QR and Temporary-Code Rules

- Permanent QR codes and temporary QR codes are both used in the platform.
- Temporary codes are retrieved through `/api/get-temp-code`.
- Temporary QR replacement is allowed later in the review stage, but capture must still store files and DB rows under the temporary code consistently.

## File Rules

- Image filenames follow:
  `<QR> <Building> <Type> - <Seq>.<ext>`
- Sequence ranges per asset type:
  - ME: `-0` Asset Plate, `-1` UBC Tag, `-2` Main Asset Photo, `-3` Technical Safety BC, `-4` Extra Photo (optional)
  - BF: `-0` Asset Plate, `-1` Asset Plate (additional), `-2` Main Photo, `-3` Extra Photo (optional)
  - EL: `-0` Asset Plate (optional), `-1` UBC Asset Tag, `-2` Panel Schedule, `-3` Extra Photo (optional)
- Elapsed-time JSON and other capture artifacts must keep QR, type, and building aligned with the captured image group.
- File and DB updates that change QR or building must be treated as one logical rename operation.

## Extra Photo Slot Rules

- The Extra Photo tile is rendered in `capture.html` with a `data-optional="true"` attribute on its `<input type="file">`.
- The completion-state JS (`updateCompletionState()`) filters out optional inputs, so the green "all required captured" toast fires once the required tiles are filled — submit is allowed without the Extra Photo.
- The submit loop iterates seqs `0..4` for ME and `0..3` for BF/EL; missing files in any slot are skipped by the existing `continue` guard, so the loop is safe regardless of which tiles the user filled.

## Image Save Rules

- `save_image_file()` in `app.py` re-encodes JPEGs through Pillow and applies `ImageOps.exif_transpose()` before writing.
- This physically rotates phone photos that arrive as landscape pixels with an EXIF Orientation tag (e.g., Orientation = 6) into upright portrait, then drops the orientation tag.
- The transpose is a no-op for images with no EXIF Orientation, with Orientation = 1, or for formats without EXIF (PNG, GIF). The existing raw-bytes fallback at the bottom of `save_image_file()` still catches corrupt-image cases.
- Historical files captured before 2026-05-25 were not backfilled; only new uploads benefit from the rotation.

## Parameter-Update Rules

- Any update that changes QR, building, asset type, or file naming context must update:
  image filenames, JSON filenames, DB rows, and processed logs.
- Roll back on failure. Do not leave partial renames behind.

## Database Rules

- `QR_codes` is the QR-level source for capture location, approval, AI status, and SDI-exclusion state.
- `QR_code_assets` tracks process placement and capture-related workflow state.
- Capture must not create malformed QR rows such as placeholder IDs.

## Cross-Platform Rules

- The app must resolve paths for both Windows development and Ubuntu production.
- Do not assume `/home/developer/...` is always available.

## Validation Checklist

- A new capture writes the expected image files.
- The QR appears in `QR_codes`.
- The asset appears in `QR_code_assets`.
- Missing-field submission does not create placeholder DB rows.
- Parameter updates do not orphan files or DB rows.

## Elapsed Time and User Tracking Rules

- After capture submission, an elapsed-time JSON (`_et.json`) is written to `Output_jason_api/`.
- The JSON includes `qr_code`, `building_number`, `asset_type`, and `elapsetime`.
- `QR_code_assets` rows include `user` (authenticated username) and `date_hour` (ISO 8601 timestamp).
- Missing `user` and `date_hour` columns are auto-created via `ALTER TABLE` if absent.

## Parameter Update Service Rules

- `utils/parameter_update_service.py` provides atomic parameter change operations.
- The service exports: `execute_parameter_update`, `get_current_params`, `get_current_asset_type`, `detect_parameter_changes`.
- The `/api/update-parameters` route delegates to this service.
- All parameter changes must update image filenames, JSON filenames, DB rows, and processed logs atomically.
- Roll back on failure â€” do not leave partial renames.
- The `/api/check-qr` route returns current parameters for comparison when the QR code already exists.
