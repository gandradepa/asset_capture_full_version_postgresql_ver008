﻿# Review App Rules

Current documentation refresh: 2026-06-03.

## Purpose

The review applications are the human-in-the-loop correction layer for ME, BF, and EL.

## Core Backend Rules

- Keep the `before_request` sync hooks active.
- Read and write JSON with `encoding='utf-8'`.
- Set `modified=true` when a save changes persisted JSON content.
- Save operations must resync curated data into the SDI tables.

## Approval Rules

- Approval toggles update both the JSON payload and DB state.
- Approval must not wipe dictionary-derived fields such as `Asset Group`, `Attribute`, `Description`, or discipline-specific derivatives.
- Package-locked rows must remain approved in review source state. If a QR appears in `sdi_print_out` or `sdi_print_out_arch`, automated ME/BF/EL JSON sync coerces review JSON `structured_data.Approved` to `"True"` and writes source approval as `"1"` (`sdi_dataset` for ME/BF, `sdi_dataset_EL` for EL).
- SDI Retrieve and Exclude actions also preserve package-source approval; Exclude returns approved, non-manual package rows to Unpackaged Assets after deleting the active package row.
- Do not add `Approved` to `sdi_print_out` or `sdi_print_out_arch`; package tables provide package state and `id_print_out`, while approval remains sourced from review JSON plus `sdi_dataset` / `sdi_dataset_EL`.
- All three review tabs (New / Update / Manual) default the `Review Status` filter to **All Statuses**.

## Manual Entry and SDI Rules

- Manual Entry is also an SDI exclusion concept.
- The following should remain aligned:
  `QR_code_assets.Col_process = 2`, JSON `ExcludeSDI`, and `QR_codes.sdi = 1`.
- A record must not appear in Manual Entry while remaining eligible for SDI packaging.

## Review Dashboard Rules

- The visible quick filters are based on current UI behavior, not on older archived controls.
- The Electrical dashboard defaults to a landing page to segment "General" vs "Distribution" assets.
- The "Update Existing" tab and "Main Asset" column are deprecated/hidden specifically in the Electrical dashboard UI.
- Confidence slicers must filter rows consistently on the frontend and backend.
- `Avg AI Conf` display and coloring should use the same value the backend exposes.
- `Package Number` is display-only on ME / BF / EL listing tables (New / Update / Manual). It appears immediately before `AI Status` (between `Main Asset` and `AI Status` in ME), displays the row's `package_id` from `sdi_print_out.id_print_out` or `sdi_print_out_arch.id_print_out`, and stays blank when no package exists.
- The styled XLSX review export (`excel_export.py` → `build_workbook`, shared identical copy in each review app) carries a matching `Package Number` column for ME / BF / EL, keyed on the same `package_id` and placed immediately before `Avg AI Conf`. Keep the export column in sync whenever the listing-table column changes.
- In the EL Distribution dashboard, the global building selector is page scope. The filter `Reset` button must preserve the current `building` / `filter_building` parameters while clearing table-level filters so users stay on the same building and route.

## Current Confidence UI Rules

- `Avg AI Conf` is part of the review dashboards for ME, BF, and EL.
- Confidence thresholds and slicer labels must match the active UI behavior.
- Any column-order changes require a check of DataTables column index references.

## Confidence and Completeness Gauge Rules

Both the "Avg AI Conf" and "Comp Score" columns on the listing tables (New / Update / Manual tabs in ME / BF / EL) render as a horizontal capsule gauge with a triangle marker positioned at the row's percentage, plus a small numeric value beneath. Shared CSS class family: `.ai-conf-meter`, `.ai-conf-bar`, `.ai-conf-marker`, `.ai-conf-value`. The capsule uses one green linear gradient, not threshold segments:

- Gradient: `linear-gradient(to right, #dcfce7 0%, #16a34a 100%)`.
- Border: `1px solid rgba(21, 128, 61, 0.45)`.
- Sizing: keep `box-sizing: border-box` so the border stays inside the 12px capsule height.

Constraints:

- Both columns use the same gauge component. Diverging the bar treatment between disciplines breaks the visual consistency users rely on for at-a-glance row scanning.
- Each cell carries `data-order="{{ score }}"` so DataTables sorts numerically; the gauge is purely visual on top.
- The cell wraps a `<div class="ai-conf-meter">` with the bar + marker + numeric value; do not move the marker outside the bar element — it is positioned with `transform: translateX(-50%)` against the bar's intrinsic width.
- Marker offset is set via inline `style="left: {{ score }}%;"`. The score must be the raw numeric (0-100), not the display string with `%`.
- The legacy `.avg-ai-conf-pill` CSS rules remain in each `dashboard.html` but are no longer referenced by markup. Remove only as part of a deliberate cleanup pass; do not introduce new uses.
- The listing DataTables saved-state version is bumped when columns are inserted (`reviewDashboardStateVersion = "package-number-v1"` as of the Package Number column) so old browser state cannot restore searches or visibility against shifted indexes.
- **`Review Status` always defaults to "All Statuses" on load** (ME / BF / EL). Server-side `approved_filter` defaults to `""`, and the listing JS forces the `#filter-approved` dropdown to `""` whenever there is no explicit `?approved=` / `?filter_approved=` URL param — it deliberately does **not** restore a persisted Approved/Pending status filter from saved DataTables state (other column filters still persist). An explicit `?approved=True|False` deep-link is still honored. Implemented by using `if (approvedParam === null)` (instead of `if (!hasApprovedState && approvedParam === null)`) in `initAssetTable`'s state-restore block. **EL extra gate:** the landing-page cards (`landing.html`) previously hardcoded `approved='False', filter_approved='False'` in the `review_all` / `review_distribution` links, which forced Pending on entry; those params were removed so EL also opens at All Statuses.
- **Listing tables default-sort by `Capture Date`, newest first** (ME / BF / EL). DataTables `order: [[colCaptureDate, 'desc']]` sets the default for fresh state; `stateLoadParams` injects the same order only when a saved state has no explicit sort, so the default also reaches existing browser state without clearing other saved filters, and a user's manual sort on another column is preserved. `Capture Date` (`date_set[:16]`, ISO `YYYY-MM-DD HH:MM`) sorts chronologically as text, so no `data-order` helper is needed.

### Avg AI Conf

- Sourced from `Avg_ai_conf` on each item dict (built by `_load_items_for_process` and equivalents). Backend pulls `_normalize_avg_ai_conf(_extract_avg_ai_conf(raw))`.
- The confidence range slider (`?conf_min` / `?conf_max`) filters rows by this field; the gauge replacement did not change that contract.

### Comp Score

- Sourced from `Comp_score` on each item dict, populated from the JSON top-level `completeness_score` field (written by `API/API_interface_*_ver00.py` during AI extraction).
- The same `_normalize_avg_ai_conf()` helper is reused as a generic 0-100 → "XX,YY%" normalizer; do not refactor it into a separate helper without coordinating all three review apps.
- If the JSON pre-dates the completeness writeback (old assets), the cell renders as `N/A`. Re-running `./run_ai_and_sync.sh <discipline> <qr_code>` populates the field.
- Column position: inserted immediately after "Avg AI Conf" on all three review-app listing pages. This insertion shifted post-column DataTables indices (`colApproved`, `colAction`, plus EL's `colAssetGroup`) — see "Listing-Page Column Visibility Rules" for the current index map.

## Listing-Page Column Visibility Rules

The review-app listing pages (`review_asset_templates/dashboard.html`) may hide fixed nameplate columns from the New / Update / Manual tab tables to keep the listing scannable. This is a presentation-only constraint: the underlying JSON payloads, `QR_code_assets`, `sdi_dataset` / `sdi_dataset_EL`, the SDI export, the Planon export, the AI extraction pipeline, and the per-asset `review.html` page all still carry every field.

Current hidden nameplate columns (0-based DataTables column index on the listing tables):

- **ME listing tables** — Manufacturer (6), Model (7), Serial Number (8), Technical Safety BC (10)
- **EL Distribution listing only** (`/review-distribution`) — Amperage Rating (7), Volts (8), Location (9)

Mechanism:

- ME uses the table `initComplete` callback to hide its fixed listing columns.
- EL Distribution gates the hide with `isDistributionDashboard`, adds the three columns to DataTables `columnDefs`, corrects restored state in `stateLoadParams`, then forces `table.column(idx).visible(false, false)` after initialization. This keeps a previously saved browser DataTables state from restoring the columns.

Constraints to preserve:

- The `<th>` and `<td>` markup for the hidden columns must stay in place; only their display is suppressed. Removing the cells would shift every downstream column index (`colTag`, `colApproved`, `colAction`, etc.) and break search / filter / bulk-action logic that references those indices.
- The per-asset review page (opened via the row's Review button) is a separate template and must continue to render every field. In particular, EL `review.html` still shows and edits `Ampere` / Amperage Rating, `Volts`, and `Location`.
- EL `Ampere` is the editable amperage source. `Amperage Rating` is the Planon-facing alias synchronized from `Ampere`; helper logic must prefer `Ampere` when both keys are present, and a submitted blank `Ampere` must clear both keys instead of falling back to a stale alias.
- EL tag-derived voltage is a default, not an override for human review. When a reviewer saves a non-derived `Volts` value, `volts_manual_override=1` preserves that value through JSON render/save and `sdi_dataset_EL` sync.
- EL `Supply From` normalization is an AI/default cleanup, not permission to erase a reviewer-entered value. When a reviewer saves a non-normalized non-empty `Supply From`, `supply_from_manual_override=1` preserves the displayed/stored text, while `Fed From Equipment ID` remains the normalized lookup/export value.
- EL review saves must keep top-level JSON quality metadata (`completeness_score`, `confidence_scores`, `Avg_ai_conf`) aligned with reviewer edits. If this metadata remains stale after a required-field edit, the EL AI checker can reprocess the JSON and erase the human correction.
- The EL General listing (`/review-all`) must continue to show those three fields unless a separate requirement changes that view.
- If a listing-table column order changes, update the DataTables index variables and hidden-column arrays in the same change.

## Photo Column Rules (Listing Tables)

- The Photo column on each dashboard table renders the required-photo ratio (`{present}/{required}`) inside a `.v2-photo-pill` capsule (red for missing, green for complete).
- When the item dict's `Extra Photo` flag is truthy, a small `.v2-photo-extra-chip` shows `+1` next to the pill with tooltip "Extra Photo present".
- The `Extra Photo` flag is populated in each reviewer's item-build path (`asset_plate_reviewer.py`, `asset_plate_reviewer_bf.py`, `Asset_dashboard_EL.py`) by calling `find_image(qr, building, <extra-seq>)` — `-4` for ME, `-3` for BF/EL.
- The chip must never roll into `Photos Summary` itself, since that fraction feeds the red/green pill semantics and the "Missed Photo" KPI. Keep the chip purely cosmetic.
- The chip markup is repeated in all three tab panes (New / Update / Manual) — the templates render the Photo cell three times per discipline. Any change to chip styling or logic must be applied to all three occurrences.
- The Photo value cells are left-aligned (`text-start`) in all New / Update / Manual listing tables for ME, BF, and EL. Keep the Photo header and adjacent action/status columns on their existing alignment unless the table layout is intentionally redesigned.

## Review Image Viewer Rules

- ME, BF, and EL `review.html` pages use the same image-viewer behavior for source-photo inspection.
- The visible controls are zoom in, zoom out, rotate clockwise, and reset image. Keep `title` and `aria-label` values on these buttons.
- The image stage is keyboard-focusable and supports `+`, `-`, `0`, `R`, and arrow-key panning.
- Mouse wheel zoom is scoped to `.main-stage`; dragging pans only the active image and must not interfere with form fields, thumbnails, Dashboard iframe scrolling, or the ME map overlay.
- Thumbnail changes reset zoom, rotation, and pan state before showing the new image.
- Each review app serves its own `review_asset_templates/static/image-viewer.js`. Keep the three copies behaviorally identical unless a deliberate shared static asset route is added.

## Bulk Action Rules (ME + BF + EL)

The ME, BF, and EL review-app tab tables (New / Update / Manual) expose **bulk Manual** and **bulk Approved** master checkboxes inside each table's column header (`<th>`). BF and EL were added to match the existing ME behavior.

- The bulk checkboxes drive a client-side queue that calls the existing per-row endpoints `POST /toggle_sdi/<doc_id>` and `POST /toggle_approved/<doc_id>`. Do not introduce a parallel bulk endpoint.
- Confirmation goes through the shared Bootstrap `#confirmModal` and the `showConfirm(title, message, onConfirm)` helper, with a `window.confirm()` fallback if the modal is unavailable.
- All three review-app modals (`#confirmModal`, `#infoModal`, `#planonModal`) use `modal-dialog modal-dialog-centered` so the dialog is vertically centered in the viewport. This matters in embedded mode: a top-aligned modal (plain `modal-dialog`) has its header clipped by the Dashboard's sticky top bar inside the iframe. Keep `modal-dialog-centered` on every modal in `dashboard.html`.
- Operate only on rows currently visible to DataTables (`rows({ search: 'applied' }).nodes()`); filters and pagination must scope the action.
- Manual / Approved header labels use the `.review-bulk-header` wrapper and table headers use vertical middle alignment so the label and checkbox stay centered.
- BF bulk header checkboxes render only when `can_edit` is true. EL relies on the existing endpoint-enforced permission behavior.
- Client-side safety filters that must remain in place:
  - Bulk-Manual skips rows where the Approved cell shows `data-search="True"`.
  - Bulk-Approved uncheck calls `GET /check_sdi/<qr_code>` first and skips rows that already exist in an SDI package.
  - ME, BF, and EL skip any package-locked row for both bulk Manual and bulk Approved. Package-locked means the QR exists in either `sdi_print_out` or `sdi_print_out_arch`.
  - Rows where the current cell state already matches the requested header state are skipped silently.
- Process rows sequentially, update each changed Manual / Approved cell in place from the endpoint response, invalidate the affected DataTables row, and redraw the current table after the queue drains.

## Rename Rules

- Only temporary QR codes may be renamed to a permanent code.
- Renames must update JSON, images, processed logs, DB rows, and review navigation context.

## Cross-App Consistency Rules

- When changing one review app, evaluate whether the same rule applies to the other two.
- Discipline-specific exceptions are valid, but they should be intentional and documented.

## Validation Checklist

- Save, approve, AI-status toggle, and SDI toggle all persist correctly.
- Manual Entry records do not leak into SDI when excluded.
- Navigation preserves dashboard filters after save / next / previous actions.
- Image viewer controls work standalone and embedded: buttons, wheel zoom, drag pan, reset, rotate, thumbnail reset, and keyboard shortcuts.

## Embedded Mode Rules (`?embedded=true`)

The review apps run both standalone (their own subdomain) and embedded (inside the central Dashboard's iframe). Embedded mode is detected once per request and used by templates to suppress sub-app chrome.

### Detection

- Each app's `before_request` hook (on `app` for ME / BF, on `main_bp` for EL) sets:
  ```python
  g.embedded = request.args.get('embedded', '').lower() == 'true'
  ```
- The hook must run for the static / image / API endpoints too so `g.embedded` is always defined when templates render. Place the assignment before any early `return` for excluded endpoints.

### Known auth-flow gotcha

- The current `auth_bp` login form (`review_asset_templates/login.html`, action `{{ url_for('auth.login') }}`) does **not** carry the `next` query parameter into the POST. The handler reads `request.args.get('next')` on POST and gets `None`, falling back to `url_for('index')`. Net effect: a user landing on `/?embedded=true` who is redirected to login is sent to plain `/` after authentication, and `g.embedded` evaluates `False` on that subsequent request.
- Practical consequence: do not depend on `?embedded=true` (or any URL flag) surviving a fresh-login round-trip in these three review apps. If a feature needs to behave differently in the iframe and is gated server-side, either fix the login template to preserve `next` (`{{ url_for('auth.login', next=request.args.get('next')) }}` or a hidden `<input name="next">`), or rely on client-side detection (`window.self !== window.top`, document referrer, etc.).
- This does not break the cross-subdomain shared-cookie flow: a user already logged in on `dashboardprod` reaches the iframe with `?embedded=true` intact, because no login redirect happens. The gotcha is specific to the fresh-authentication path (incognito, expired session, password reset, etc.).

### Cookie configuration

- Every review app must set `SESSION_COOKIE_SAMESITE='None'`, `SESSION_COOKIE_SECURE=True`, `SESSION_COOKIE_HTTPONLY=True`, plus the matching `REMEMBER_COOKIE_*` triple.
- These are required for cross-subdomain cookie delivery from the Dashboard iframe; without them the sub-app sees no session and immediately redirects to login.

### Template rules

- The top user-nav (`.user-nav`), brand header, page-header logo block, and user dropdown are wrapped in `{% if not g.embedded %}` so they do not render inside the iframe.
- Functional controls (building selector, archive toggle, "User Activity" button, meta-pills, approve toggle, "Dashboard" back-to-list button) must remain visible in embedded mode. Do not hide the entire toolbar.
- The body element receives `embedded-mode` as a class when `g.embedded` is true. CSS uses this class as a belt-and-suspenders fallback.
- Internal back-to-list links (`url_for('index')` for ME / BF, `url_for(base_route)` for EL, `url_for('main.dashboard')` for SDI) must append `?embedded=true` when `g.embedded` is true so embedded state survives back-navigation.

### Link propagation script

- Each sub-app template includes a small bottom-of-body script that intercepts `<a>` clicks. If `?embedded=true` is in the current URL it appends `?embedded=true` (or `&embedded=true`) to internal links before the browser navigates.
- The script ignores anchor-only (`#`), absolute (`http://`), and `mailto:` hrefs.
- DataTables-rendered links must still be intercepted; the listener is attached to `document` so it works regardless of when rows are rendered.

### Cross-origin "back to main" navigation

- The "Dashboard" button that navigates back to the central main view lives in the central Dashboard's process-view-header, not inside the sub-app. Sub-apps do not need their own button for this.
- Optional cross-origin notification uses `window.parent.postMessage({action:'go-to-main'}, 'https://dashboardprod.assetcap.facilities.ubc.ca')`. The target origin must match the central Dashboard's actual hostname exactly; mismatched origins cause silent message drops.

### EL-specific extras

- EL has three templates that need embedded treatment: `landing.html`, `dashboard.html` (review-all / review-distribution), and `review.html`.
- EL `dashboard.html` must include `_shell.html` in the `<head>` like ME and BF. The shared shell script suppresses itself inside iframe / `?embedded=true` contexts and adds `acshell-host` spacing only for standalone pages.
- EL's standalone `Main Dashboard` button inside the toolbar links to `url_for('main.landing')?embedded=true`, returning the user to the EL hub page within the iframe.
- EL required-field checklist popovers (`.el-required-popover`) are appended to `body` and must sit above the shared shell sidebar (`.acshell-sidebar` uses `z-index: 9998`). Keep the popover layer above that value (`--bs-popover-zindex` / `z-index: 10050`) so hover cards are not clipped by the shell.

## Archive visibility, SLD dropdown, and approval UI (2026-06-01)

- **Archive toggle = persistent pressed state (ME / BF / EL, 2026-06-01).** State is `archive_filter_active = (request.args.get("archive") != 'false')`; "archived" means the QR appears in `sdi_print_out_arch` (`get_archived_qrs()`). The review header button **always reads "Show Archive"**; when archived rows are shown (`archive_filter_active` is false) it carries the `v2-header-btn--archive-on` class and is shaded cream (`#fff8dc`, inset shadow) to read as "pressed". The pressed state is server-driven from the `archive` URL param, so it survives reloads and clears only on un-press (click again) or filter **Reset** (`resetFilters()` deletes `archive`). All three review apps share this; EL additionally widens its building selector (`.v2-building-select`) to 480px max / 400px min.
- **Filters preserve each other's params.** `updateDashboardQuery()` no longer deletes `archive` on a Review Status / tab change, and the archive button carries the current `approved` filter (`url_for(..., approved=approved_filter_raw)`). Consequence: an *Approved + Show Archive* view holds across reloads — previously each control reset the other's URL param. Applies to EL, ME, and BF.
- **EL SLD building dropdown is archive-aware.** `get_buildings(include_archived=False)` in `sld_blueprint.py` lists a building only if it has at least one `sdi_dataset_EL` QR not in `sdi_print_out_arch`; a building whose QRs are all archived is hidden. `GET /sld/api/buildings?include_archived=true` returns the unfiltered list. EL-specific.
- **Bulk Approve surfaces errors.** The `select-all-approved` handler records per-row failures and shows a summary modal (auth/session/server) at the end instead of silently no-op'ing. EL-specific.
- **ME/BF/EL package lock for status fields.** `AI Status`, `Manual`, and `Approved` are read-only when the QR appears in active package table `sdi_print_out` or archive table `sdi_print_out_arch`; `/check_sdi/<qr>` reports both tables and the three per-row toggle endpoints return HTTP `409` before writing DB or JSON state.
- **Package approval guard.** Automated review JSON sync must not clear approval for any QR already in `sdi_print_out` or `sdi_print_out_arch`; it rewrites JSON approval to `"True"` when needed and persists source-table approval as `"1"`.
- **Flow integrity audit + remediation.** `scripts/audit_sdi_flow_integrity.py` (read-only) flags assets stuck in the approve→package→archive flow; `special_processes/sdi_flow_remediation.md` documents per-asset remediation using the app endpoints (`/toggle_sdi`, `/toggle_approved`, `/review`) — never raw DB/JSON edits except approved, backed-up production migrations with a timestamped report.
