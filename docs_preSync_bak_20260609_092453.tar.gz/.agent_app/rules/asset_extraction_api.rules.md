# Extraction API Rules

Current documentation refresh: 2026-05-27.

## Purpose

The extraction layer reads captured images, performs OCR and LLM extraction, writes JSON, and updates workflow state in `QR_codes.db`.

## Script Shape

- ME, BF, and EL extraction scripts use `Config` plus `AssetProcessor`.
- Use `ThreadPoolExecutor` with the script's configured `MAX_WORKERS`.
- Use structured schema validation before saving output.

## JSON Save Guard

- Extraction may overwrite an existing JSON only when the new result is at least as complete as the existing result.
- Even when save is skipped, `ai_status` still needs to be updated so the same asset does not loop forever.
- EL's existing-JSON skip must not apply when `_existing_el_output_needs_rescore()` says the payload is stale under the current extraction rules. In that case the processor must continue extraction and rewrite the stale JSON so `ai_status` can settle back to `1`.
- EL approved / SDI-locked rows must not be reset from `ai_status=1` back to `0` by the stale-JSON detector, because the worker deliberately excludes approved rows from AI reprocessing.
- EL human-reviewed JSON is authoritative. `_existing_el_output_needs_rescore()` must not flag payloads with `modified=true`, `supply_from_manual_override=1`, or `volts_manual_override=1` for AI rerun, because re-extraction can erase reviewer corrections.

## Discipline-Specific Completeness

- ME completeness:
  `Manufacturer`, `Model`, `Serial Number`, `Year`, `UBC Tag`, plus `Technical Safety BC` only when seq `-3` exists.
- BF completeness:
  `Manufacturer`, `Model`, `Serial Number`, `Diameter`.
- EL completeness:
  `UBC Asset Tag`, `Ampere`, `Supply From`.

## Discipline-Specific Confidence

- Confidence must be reconciled against the final saved field values.
- Blank final fields must not retain stale non-zero confidence.
- EL averages exclude `Volts`, `Location`, and `Branch Panel`.
- ME includes `Technical Safety BC` only when seq `-3` exists.
- When source confidence is missing, synthesized confidence should come from actual evidence, not from placeholder zeros pretending to be certainty.

## ME Ownership Rules

- Seq `-0` owns `Manufacturer`, `Model`, `Serial Number`, and `Year`.
- Seq `-1` owns `UBC Tag`.
- Seq `-3` owns `Technical Safety BC`.
- Seq `-4` is the optional **Extra Photo** slot, owns no fields, and is never sent to the LLM (excluded via `VALID_SUFFIXES`).
- If the owning source is absent or not evidenced, leave the field blank.

## Extra Photo Exclusion (All Disciplines)

- ME, BF, and EL all support one optional **Extra Photo** sequence: ME `-4`, BF `-3`, EL `-3`.
- The pipeline's `FILENAME_PATTERN` regex was widened so discovery can see the file and log it as `invalid_seq` rather than `name_mismatch`.
- The actual gate is `VALID_SUFFIXES`, which was left unchanged. Extra Photo sequences are deliberately absent from each `VALID_SUFFIXES` set, so they are discovered, logged, and skipped before being added to `info["images"]`.
- Do not promote an Extra Photo sequence into `VALID_SUFFIXES` for "more data" — it carries no field-owner contract and would introduce ambiguous evidence.

## OCR and Prompting Rules

- OCR is a recovery and evidence layer, not permission to hallucinate.
- Prompt guidance and merge logic may be discipline-specific when required by plate layout.
- For ME, seq-0 plate evidence is critical for model and serial acceptance on difficult families such as Rheem / Ruud water heaters.

## DB Sync Rules

- JSON-to-DB sync helpers must upsert curated rows rather than append duplicates.
- `sdi_dataset` is for ME and BF.
- `sdi_dataset_EL` is for EL.
- `Avg_ai_conf` must be preserved through sync when present.

## Error-Handling Rules

- A single-asset failure must not crash the batch.
- Catch file, OCR, API, and validation errors and continue.
- Log enough context to find the failing QR, discipline, and building.

## Chained Execution Rules

- `run_ai_and_sync.sh` chains AI extraction to DB sync automatically.
- This is the recommended launch method from the Dashboard.
- The separate manual `update_db` task has been removed from the Dashboard launcher.

## Shared Validator Rules

- `validators_shared.py` provides validation utilities shared across ME, BF, and EL scripts.
- Extraction scripts should use shared validators rather than duplicating validation logic.
