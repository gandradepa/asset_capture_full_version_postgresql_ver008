﻿# Attribute Changes

Current documentation refresh: 2026-06-03.

## 2026-06-03: FLS New Device Flow Control Panel lookup

### Summary

Dashboard `1. New FLS Device Flow` now derives Control Panel `Code` and `Description` from `"UBC - Asset Data Master Info"` by selected building `Property code`.

### Behavior

- The lookup is display-only; no `new_device` schema change or persisted Control Panel snapshot was added.
- If a property has multiple matching Control Panel rows, Dashboard displays the lowest `Code` row and flags the row/form as multi-match.
- The primary FLS table hides `Asset Group`, `Space`, and `Details` in the New Device Flow view.
- Those hidden fields remain available in Edit and the magnifying-glass details modal.

## 2026-06-03: Asset system code text normalization

### Summary

The VM `Asset_System_info` view now exposes asset master `"Code"` values as 10-character zero-padded text.

### Behavior

- `Asset_System_info` is a view; the source column is `"UBC - Asset Data Master Info"."Code"`.
- The source column was rebuilt from `INTEGER` to `TEXT`.
- All 150 source rows were normalized to 10 characters, including `54137 -> 0000054137` and `154409 -> 0000154409`.
- `PRAGMA integrity_check` returned `ok` after the migration and VM-side `VACUUM`.
- Current production DB path: `/home/developer/asset_capture_app_dev/data/QR_codes.db`.
- Backup files under `/home/developer/asset_capture_app_dev/data/`, `/home/developer/backup_app/`, and deployment backup folders can still show the old integer values and are not current production state.

### VM backups

- `/home/developer/asset_capture_app_dev/data/QR_codes.bak_20260603_152011_asset_system_code_text.db`
- `/home/developer/asset_capture_app_dev/data/QR_codes.bak_20260603_152154_before_vacuum_after_asset_system_code_text.db`

## 2026-06-03: Review Photo column left alignment

### Summary

The Photo value cells in the ME, BF, and EL review dashboard listing tables now align their photo-status pills to the left.

### Behavior

- Applies to the Photo column in all three review dashboard tabs: New, Update, and Manual.
- The cell class changed from `text-center` to `text-start` for the Photo value cells only.
- The Photo header, Review action column, status columns, JSON/DB state, SDI behavior, and photo-count logic are unchanged.
- VM deployment backup: `/home/developer/deploy_backups/review_photo_left_align_20260603_131754`.

### Files updated

- ME review template: `review/Asset_dasboard_browser_ME/review_asset_templates/dashboard.html`
- BF review template: `review/Asset_dasboard_browser_BF/review_asset_templates/dashboard.html`
- EL review template: `review/Asset_dashboard_browser_EL/review_asset_templates/dashboard.html`
- Review rules and workflow docs updated in canonical and mirrored documentation.

## 2026-06-03: Sidebar Performance Analysis label

### Summary

The shared application shell now labels the former `Cost Analysis` navigation item as `Performance Analysis` and uses a gauge-style icon to better match the operational data-quality chart.

### Behavior

- The shared shell sidebar label changed from `Cost Analysis` to `Performance Analysis` in Dashboard, SDI Process, ME Review, BF Review, and EL Review.
- The icon changed from the dollar symbol to a Lucide-style gauge icon.
- The historical route key remains `cost`, and the RBAC item key remains `cost_analysis`; only the visible label changed.
- The Dashboard monitoring card and RBAC registry label were aligned to the new visible text.
- VM deployment backup: `/home/developer/deploy_backups/sidebar_performance_analysis_20260603_111550`.

### Files updated

- Shared shell JS:
  - `Dashboard/static/shell/shell.js`
  - `SDI_process/static/shell/shell.js`
  - `review/Asset_dasboard_browser_ME/review_asset_templates/static/shell/shell.js`
  - `review/Asset_dasboard_browser_BF/review_asset_templates/static/shell/shell.js`
  - `review/Asset_dashboard_browser_EL/review_asset_templates/static/shell/shell.js`
- Dashboard template: `Dashboard/templates/dashboard.html`
- RBAC registry: `auth_service/app_registry.py`
- Canonical and mirrored documentation updated to use `Operational Performance Analysis`.

## 2026-05-29: Centered modal dialogs in review apps and dashboard dictionary

### Summary

All Bootstrap modal dialogs in the ME, BF, and EL review apps and the Dashboard dictionary-management view now render vertically centered (`modal-dialog-centered`) instead of pinned to the top of the viewport.

### Behavior

- Previously the review-app modals (`#planonModal`, `#infoModal`, `#confirmModal`) and the dictionary `#deleteModal` used a plain `<div class="modal-dialog">`, so Bootstrap positioned them near the top of the scroll area.
- When a review app runs embedded in the Dashboard iframe, that top-aligned position tucked the dialog header under the Dashboard's sticky top bar (for example, the "Confirm Bulk Action" dialog was partially hidden).
- Each affected modal now uses `<div class="modal-dialog modal-dialog-centered">`, so the dialog sits in the vertical center of the iframe panel, clear of the top bar. The iframe panels are fixed height (`calc(100vh - 130px)`), so centering lands inside the visible area.
- This aligns the review apps and dictionary view with the SDI Process, main Dashboard, and Capture app, which already used `modal-dialog-centered`.
- Presentation-only change: no SQL, discipline, completeness, confidence, or SDI-sync behavior is affected.

### Files updated

- ME review template: `review/Asset_dasboard_browser_ME/review_asset_templates/dashboard.html`
- BF review template: `review/Asset_dasboard_browser_BF/review_asset_templates/dashboard.html`
- EL review template: `review/Asset_dashboard_browser_EL/review_asset_templates/dashboard.html`
- Dashboard dictionary template: `Dashboard/templates/index_dictionary.html`
- Review rules: `Markdowns_documentation/rules/review_apps.rules.md`
- Dashboard rules: `Markdowns_documentation/rules/dashboard.rules.md`

## 2026-05-28: EL amperage reviewer override preservation

### Summary

EL review saves now preserve a reviewer-entered `Ampere` / `Amperage Rating` value when the editable `Ampere` field differs from the existing Planon-facing `Amperage Rating` alias.

### Behavior

- The EL amperage resolver now treats `Ampere` as the editable source of truth and `Amperage Rating` as the fallback alias.
- A stale `Amperage Rating` value can no longer overwrite a submitted `Ampere` value during save.
- A submitted blank `Ampere` value is now treated as an intentional clear and blanks both `Ampere` and `Amperage Rating`; it no longer falls back to the previous alias value.
- On save, both `Ampere` and `Amperage Rating` are still synchronized to the same numeric value and `Amperage Rating (UoM)` is still derived as `AMP` when present.
- This is the same class of issue as the EL `Supply From` cleanup bug: internal normalization overwrote a reviewer correction. The specific mechanism is alias precedence, not AI stale-output reprocessing.

### Files updated

- EL review/save: `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- Regression test: `test/test_el_amperage_alias.py`

## 2026-05-28: EL Distribution filter reset preserves building scope

### Summary

The `Reset` control in the EL Distribution review dashboard now clears table filters without dropping the currently selected building or leaving the `/review-distribution` page.

### Behavior

- Reset keeps the global building selector value by restoring both `building` and `filter_building` in the clean query string.
- Reset still clears QR, date, UBC tag, asset group, captured-by, approved, confidence, traffic-light, quick-view, and archive filters.
- The reload target is rebuilt from the current route, preserving `?embedded=true` when present and avoiding navigation through browser history.

### Files updated

- EL dashboard template: `review/Asset_dashboard_browser_EL/review_asset_templates/dashboard.html`

## 2026-05-28: EL Supply From reviewer override preservation

### Summary

EL review saves now preserve a human-entered `Supply From` value instead of always replacing it with the AI/extraction normalizer result.

### Behavior

- If a reviewer enters a non-empty `Supply From` value that differs from the normalized equipment ID, the JSON stores `supply_from_manual_override=1` and keeps the reviewer text.
- `Fed From Equipment ID` remains normalized from `Supply From` and is still used for parent amperage lookup / export alignment.
- EL DB sync no longer bulk-rewrites `sdi_dataset_EL."Supply From"` during derived-field maintenance; it updates `Fed From Equipment ID` separately.
- EL review saves refresh `completeness_score`, `confidence_scores`, and `Avg_ai_conf` metadata after reviewer edits so the AI checker does not classify the saved JSON as stale.
- The EL AI stale-output detector treats `modified=true`, `supply_from_manual_override=1`, and `volts_manual_override=1` JSON payloads as human-reviewed and does not reprocess them.
- ME and BF do not have the EL `Supply From` cleanup path. Their primary reviewer fields are still saved directly, with existing dictionary-derived behavior for Asset Group / Description unchanged.

### Files updated

- EL review/save: `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- EL extraction: `API/API_interface_EL_ver00.py`
- Review rules: `Markdowns_documentation/rules/review_apps.rules.md`

## 2026-05-27: Review dashboard bulk toggles and EL Distribution presentation

### Summary

The review dashboards were aligned so BF and EL have the same Manual / Approved header-checkbox bulk actions already used by ME. EL Distribution also received presentation-only cleanup for the listing table and shared shell behavior.

### Review dashboard bulk actions

- BF and EL New / Update / Manual tables now render `.select-all-manual` and `.select-all-approved` header checkboxes in the Manual and Approved columns.
- Bulk actions are client-side queues through existing endpoints only: `POST /toggle_sdi/<doc_id>`, `POST /toggle_approved/<doc_id>`, and `GET /check_sdi/<qr_code>`.
- Bulk Manual applies only to currently filtered DataTables rows whose Manual state differs from the target, and skips Approved rows.
- Bulk Approved applies only to currently filtered rows whose Approved state differs from the target. Unchecking Approved calls `/check_sdi/<qr_code>` first and skips exported / Planon-locked rows.
- BF header checkboxes render only when `can_edit` is true. EL keeps its existing endpoint-enforced permissions.
- Manual / Approved header labels were vertically centered with the checkbox using `.review-bulk-header` and table-header vertical alignment.

### EL Distribution presentation

- EL `dashboard.html` now includes `_shell.html`, matching ME and BF standalone sidebar/topbar behavior. The shared shell still suppresses itself inside iframe / embedded contexts.
- The "Review Electrical Assets - Distribution" listing view hides Amperage Rating, Volts, and Location from its New / Update / Manual DataTables. The hide is scoped to Distribution and is presentation-only; `review.html`, `/review-all`, JSON, DB state, SDI packaging, and Planon export still carry those fields.
- EL required-field checklist popovers now set `.el-required-popover` above the shared shell sidebar z-index so QR hover cards are not covered by the shell.
- EL review saves now preserve an explicit reviewer-entered `Volts` value with a `volts_manual_override` marker so tag-derived voltage defaults do not overwrite human edits during JSON save or `sdi_dataset_EL` sync.

### EL AI status stale JSON repair

- EL `ai_status=1` rows are only treated as processed when a current usable EL JSON exists. Stale JSON rows are reset to `ai_status=0` so the AI worker can refresh them under the current extraction rules.
- The EL processor no longer applies the existing-JSON skip to stale payloads. When `_existing_el_output_needs_rescore()` flags the JSON, extraction continues and rewrites the stale payload even when `EL_OVERWRITE_EXISTING_JSON=false`; current JSON files still keep the skip guard.
- Approved / SDI-locked EL rows are exempt from stale-JSON resets because the AI worker deliberately excludes approved rows from reprocessing.
- This prevents rows such as QR `0000184448` from repeatedly returning to `AI Status = FALSE` after an operator toggles them true.

### Files updated

- BF dashboard: `review/Asset_dasboard_browser_BF/review_asset_templates/dashboard.html`
- EL dashboard: `review/Asset_dashboard_browser_EL/review_asset_templates/dashboard.html`
- EL review/save: `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- EL extraction: `API/API_interface_EL_ver00.py`

## 2026-05-25: Photo orientation EXIF transpose

### Summary

`save_image_file()` in `asset_capture_app_dev/app.py` now applies `PIL.ImageOps.exif_transpose()` immediately after `Image.open()`. Phone photos that arrive as landscape-pixel JPEGs with an EXIF Orientation tag (typically `Orientation: 6 - rotate 90 CW`) are now physically rotated to portrait before being written to `Capture_photos_upload/`, and the orientation tag is removed so downstream viewers do not double-rotate.

### Scope of change

- Single change in `save_image_file()`: `from PIL import Image, ImageOps`, then `img = ImageOps.exif_transpose(img)` before the existing save branches.
- Catches every upload path (camera modal, gallery pick, future API client) because all paths flow through `save_image_file()`.
- No client-side change; `capture.html` `ensurePortraitOrientation()` and `previewImage()` are unchanged.
- No backfill — historical files captured before 2026-05-25 remain in their original orientation on disk. Only new uploads are corrected.

### Why not client-side

- The browser's `img.width / img.height` does not auto-read EXIF, so the existing JS heuristic could not see the orientation hint.
- The gallery-pick path bypassed the JS orientation logic entirely.
- A server-side fix is browser-agnostic and authoritative for any future upload route.

### Files updated

- `asset_capture_app_dev/app.py` (`save_image_file()`)

## 2026-05-21: Extra Photo slot (ME, BF, EL)

### Summary

Each discipline now exposes one optional **Extra Photo** capture slot: ME `-4`, BF `-3`, EL `-3`. The slot is visible in capture and review but excluded from completeness, AI confidence, AI extraction, and the "Missed Photo" count. In review dashboards it renders as a small `+1` chip next to the existing required-photo ratio in the Photo column.

### Capture app

- New tile "Extra Photo (Optional)" added to all four asset-type field lists in `capture.html`.
- The Extra Photo `<input type="file">` carries `data-optional="true"`; `updateCompletionState()` filters by `:not([data-optional="true"])` so the green "all required captured" toast fires once the required tiles are filled.
- Submit loop in `app.py` now iterates seqs `0..4`; missing files in any slot are skipped by the existing `continue` guard.
- `seq_to_label()` returns "Extra Photo" for the new index in every asset map.

### Review dashboards (ME / BF / EL)

- `SEQ_SHOW` (ME) / `ALL_SHOW` (EL) widened to include the new index. `SEQ_CHECK` / `REQUIRED` unchanged — the new slot never counts toward "Missed Photo".
- `IMG_NAME_RE` regexes widened from `[0-3]` (ME) / `[0-2]` (EL) to include the new index. BF was already `[0-3]`.
- Each item dict carries a new `Extra Photo` boolean populated by `find_image(qr, building, <extra-seq>)`.
- The Photo column cell adds `{% if item['Extra Photo'] %}<span class="v2-photo-extra-chip">+1</span>{% endif %}` in all three tab panes (New / Update / Manual). A new `.v2-photo-extra-chip` CSS rule was added to each dashboard stylesheet.
- The thumbnail-strip label map in `review.html` adds the Extra Photo label.
- Pagination preview's `label_map` was extended in the same way.

### AI extraction pipelines (`API/`)

- `FILENAME_PATTERN` regex widened: ME `[0-3]` → `[0-4]`, BF `[01]` → `[0-3]`, EL `[012]` → `[0-3]`. This lets discovery see the Extra Photo file and log it as `invalid_seq` rather than the noisier `name_mismatch`.
- `VALID_SUFFIXES` was deliberately **not** changed. The Extra Photo's sequence remains absent from each pipeline's `VALID_SUFFIXES`, so the file is discovered, logged, and skipped before being added to `info["images"]`. The LLM never sees it.
- ME's optional `role_map` got `"4": "Extra Photo"` entries in `_llm_multi_image()` and `_llm_multi_image_simple()` for log readability if discovery ever surfaces the file.

### Files updated

- Capture: `asset_capture_app_dev/app.py`, `asset_capture_app_dev/templates/capture.html`
- Review ME: `review/Asset_dasboard_browser_ME/asset_plate_reviewer.py`, `review_asset_templates/dashboard.html`, `review_asset_templates/review.html`
- Review BF: `review/Asset_dasboard_browser_BF/asset_plate_reviewer_bf.py`, `review_asset_templates/dashboard.html`, `review_asset_templates/review.html`
- Review EL: `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`, `review_asset_templates/dashboard.html`, `review_asset_templates/review.html`
- AI: `API/API_interface_ME_ver00.py`, `API/API_interface_BF_ver00.py`, `API/API_interface_EL_ver00.py`

## 2026-03-31: EL amperage storage shift

### Summary

Electrical amperage is now stored canonically in `sdi_dataset_EL."Amperage Rating"`.
The legacy `sdi_dataset_EL."Ampere"` column remains in place as a compatibility mirror during the transition.

This phase does not rename the EL extractor JSON contract or the EL review form.
Those surfaces still use `Ampere`, and the EL sync layer maps the value into both database columns.

### Scope of change

- `sdi_dataset_EL."Amperage Rating"` is now the curated EL source of truth.
- `sdi_dataset_EL."Ampere"` is still populated with the same value for compatibility.
- EL JSON payloads still use `structured_data.Ampere`.
- EL review UI still shows and edits `Ampere`.
- SDI export now prefers the canonical EL amperage value and falls back safely to the legacy one.

### Amperage format rule

EL amperage values now store integer-only text with no unit suffix.

Examples:

- `225A` -> `225`
- `600 amps` -> `600`
- `1200 A` -> `1200`

The unit is handled separately by downstream fields such as `Amperage Rating (UoM)`.

### Implementation notes

#### EL review and DB sync

- Added EL amperage normalization in the EL review/sync service.
- Sync now derives one amperage value from:
  - `structured_data["Amperage Rating"]` if present
  - otherwise `structured_data["Ampere"]`
- Sync dual-writes:
  - `sdi_dataset_EL."Amperage Rating"`
  - `sdi_dataset_EL."Ampere"`

#### Database migration and backfill

- Added an idempotent migration path to ensure `sdi_dataset_EL."Amperage Rating"` exists.
- Backfilled blank `Amperage Rating` values from legacy `Ampere`.
- Added and populated `sdi_dataset_EL."Amperage Rating (UoM)"` using the rule:
  - `AMP` when `Amperage Rating` is present
  - blank when `Amperage Rating` is blank
- Normalized existing EL DB values so amperage is stored without `A` or other letter suffixes.

#### EL extraction

- EL extraction still returns the `Ampere` key.
- Shared amperage normalization now strips unit letters and keeps only the integer value.
- EL extraction prompt was updated to request integer-only amperage.

#### SDI export

- EL rows are normalized before export so `Amperage Rating` is the active SDI Process field.
- SDI Process package handling now uses `Amperage Rating` as its internal amperage column.
- SDI Process now carries `Amperage Rating (UoM)` in package tables and uses the stored value for template fill.
- Package tables keep compatibility with older `Ampere` data by backfilling `Amperage Rating` where needed.

### Files updated

- `API/validators_shared.py`
- `API/API_interface_EL_ver00.py`
- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `SDI_process/app.py`
- `01_GLOBAL_RULES.md`
- `UBC_Asset_Capture_Application_Documentation.md`
- `UBC_Asset_Capture_Application_Server_Documentation.md`
- `UBC_Asset_Capture_Application_Technical_Documentation.md`
- `review/.agent/AGENT.md`
- `asset_capture_app_dev/.agent/QR_codes_db_schema.md`

### Data updates applied

#### SQLite database

- Updated live EL rows in `asset_capture_app_dev/data/QR_codes.db`
- Backfilled `Amperage Rating` from `Ampere`
- Normalized EL amperage values to integer-only text

#### EL JSON payloads

- Normalized existing `Output_jason_api/*_EL_*.json` amperage values to integer-only text
- Kept `Ampere` as the active JSON field
- Wrote `Amperage Rating` where needed for compatibility with the new DB sync rule

### Backups created

- `asset_capture_app_dev/data/QR_codes.db.bak_20260331_1540`
- `asset_capture_app_dev/data/QR_codes.db.bak_20260331_1622_amperage_shift`
- `asset_capture_app_dev/data/QR_codes.bak_20260331_160514_amp_numeric.db`
- `Output_jason_api_backup_20260331_160514_amp_numeric/`

### Validation completed

- Python compile checks passed for the updated EL/API/export modules.
- `sdi_dataset_EL` row count remained unchanged.
- Existing EL amperage values were copied into `Amperage Rating`.
- EL DB rows with letter suffixes in amperage fields: `0`
- EL JSON payloads with letter suffixes in amperage fields: `0`

### Compatibility notes

- `Ampere` is still the visible EL review field.
- `Ampere` is still the active EL extraction JSON key.
- `Amperage Rating` is now the canonical curated DB field.
- Both DB columns currently store the same integer-only value.

### Follow-up options

- Full EL field rename from `Ampere` to `Amperage Rating` in JSON and UI
- Removal of the `Ampere` compatibility mirror after all downstream consumers are updated
- Additional audit for any external integrations that may still expect values like `225A`

## 2026-04-01: Production-safe SQLite amperage migration script

### Summary

Added a standalone SQLite migration script so production can be backfilled immediately after deployment, without waiting for EL review traffic or SDI package flows to touch the rows.

### Script

- `scripts/backfill_amperage_columns_sqlite.py`

### What it does

- Creates a consistent SQLite backup before making changes
- Ensures these columns exist where needed:
  - `Equipment ID`
  - `Equipment Type`
  - `Amperage Rating`
  - `Amperage Rating (UoM)`
- Backfills `Equipment ID` from the curated UBC tag source
- Backfills `Equipment Type` from `Equipment ID` or the UBC tag source using the shared EL prefix mapping
- Applies the current amperage normalization rule:
  - keep only the integer part of amperage values
- Backfills and synchronizes these tables:
  - `sdi_dataset_EL`
  - `sdi_print_out`
  - `sdi_print_out_arch`
- Sets `Amperage Rating (UoM)` to `AMP` when `Amperage Rating` is populated, else blank
- Mirrors the normalized value into legacy `Ampere` where that column exists

### Intended use

- Run once on the deployed SQLite database after the new application code is in place
- Recommended first step:
  - `python scripts/backfill_amperage_columns_sqlite.py --db /path/to/QR_codes.db --dry-run`
- Apply:
  - `python scripts/backfill_amperage_columns_sqlite.py --db /path/to/QR_codes.db`

### Notes

- The script is idempotent and can be re-run safely
- It is intended as the immediate production backfill step so the DB is fully updated even before users touch the EL review or SDI package routes

## 2026-04-01: EL Equipment ID source shift

### Summary

`sdi_dataset_EL."Equipment ID"` is now the canonical EL source for Planon `Equipment ID`.
The value remains auto-derived from the curated EL tag source rather than being user-entered.

### Implementation notes

- EL review/DB sync now writes `Equipment ID` into `sdi_dataset_EL` on every sync.
- The current derivation rule is preserved:
  - `Equipment ID` is copied from the curated EL `UBC Asset Tag` value.
- SDI package tables now carry `Equipment ID` so the value survives package creation, archive, and retrieval.
- Planon export now reads stored `Equipment ID` first and falls back to legacy `UBC Tag` only when the canonical field is blank.
- The SQLite migration script now backfills `Equipment ID` in `sdi_dataset_EL`, `sdi_print_out`, and `sdi_print_out_arch`.

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `SDI_process/app.py`
- `scripts/backfill_amperage_columns_sqlite.py`

## 2026-04-02: EL `Fed From Amperage Rating (UoM)` standardization

### Summary

`Fed From Amperage Rating (UoM)` is now stored as a derived standard field instead of remaining unmapped.

### Rule

- If `Fed From Amperage Rating` has a value:
  - set `Fed From Amperage Rating (UoM) = A`
- If `Fed From Amperage Rating` is blank:
  - keep `Fed From Amperage Rating (UoM)` blank

### Scope

- EL DB sync in `sdi_dataset_EL`
- EL historical backfill in `sdi_dataset_EL`
- SDI package tables:
  - `sdi_print_out`
  - `sdi_print_out_arch`
- Planon export/template fill from the stored field
- EL review form display as a read-only `UoM` field beside `Fed From Amp Rating`

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `review/Asset_dashboard_browser_EL/review_asset_templates/review.html`
- `SDI_process/app.py`
- `scripts/backfill_amperage_columns_sqlite.py`

## 2026-04-07: SDI carry-through for EL `Power Rating`

### Summary

The SDI process now carries stored EL `Power Rating` and `Power Rating (UoM)` values from `sdi_dataset_EL` into package tables and the export template.

### Rule

- Source of truth is `sdi_dataset_EL`
- SDI package tables preserve:
  - `Power Rating`
  - `Power Rating (UoM)`
- Export uses the stored DB values directly
- If `Power Rating` is blank, `Power Rating (UoM)` stays blank
- No SDI-side derivation or inference is added

### Scope

- SDI package creation
- `sdi_print_out`
- `sdi_print_out_arch`
- SDI export/template fill
- SQLite migration/backfill script for existing package rows

### Files updated

- `SDI_process/app.py`
- `scripts/backfill_amperage_columns_sqlite.py`

## 2026-04-07: EL `Power Type` source-of-truth shift

### Summary

`Power Type` is now treated as a stored EL field instead of existing only as an SDI export-time derived value.

### Rule

- Canonical stored value is the short system code:
  - `N`
  - `E`
  - `S`
  - `NE`
  - `ES`
  - `NS`
  - `NES`
- Derive `Power Type` from:
  - `Equipment ID`
  - fallback `UBC Asset Tag`
- Export uses the stored field first and only falls back to parsing `Equipment ID` when the stored value is blank.

### Scope

- EL DB sync in `sdi_dataset_EL`
- EL historical backfill in `sdi_dataset_EL`
- SDI package tables:
  - `sdi_print_out`
  - `sdi_print_out_arch`
- Planon export/template fill from the stored field

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `SDI_process/app.py`
- `scripts/backfill_amperage_columns_sqlite.py`

### Additional UI update

- The EL review form now shows `Power Type` in the `Technical Details` section as a read-only derived field.
- The displayed value comes from the same canonical short-code logic stored in `sdi_dataset_EL`.

### Review UI

- The EL review form now shows `Fed From Amperage Rating` in the `Technical Details` section.
- The field is read-only because it is DB-derived from the same-building `Supply From -> UBC Asset Tag` lookup.
- Review load and save both recompute the displayed value so it stays aligned with the current `Supply From` value.

### Additional file updated

- `review/Asset_dashboard_browser_EL/review_asset_templates/review.html`
- `UBC_Asset_Capture_Application_Technical_Documentation.md`
- `asset_capture_app_dev/.agent/QR_codes_db_schema.md`

### Compatibility notes

- The EL review UI still does not expose `Equipment ID` as an editable field.
- Users continue to edit `UBC Asset Tag`; `Equipment ID` is derived in the backend.
- The existing `Power Type` and `Equipment Type` parsing logic is unchanged and still uses `Equipment ID` as its input.

### Local migration and validation

- Updated local SQLite DB: `asset_capture_app_dev/data/QR_codes.db`
- Backup created: `asset_capture_app_dev/data/QR_codes.bak_20260401_094215_amperage_columns_migration.db`
- Post-backfill counts:
  - `sdi_dataset_EL`: `176` total, `171` nonblank `Equipment ID`
  - `sdi_print_out`: `16` total, `0` nonblank `Equipment ID`
  - `sdi_print_out_arch`: `388` total, `141` nonblank `Equipment ID` (matching current archived electrical rows)

## 2026-04-01: EL Equipment Type source shift

### Summary

`sdi_dataset_EL."Equipment Type"` is now the canonical EL source for Planon `Equipment Type`.
The value remains auto-derived from the EL tag pattern rather than being user-entered.

### Implementation notes

- EL review/DB sync now writes `Equipment Type` into `sdi_dataset_EL` on every sync.
- The current derivation rule is preserved and shared across EL sync, package backfill, and Planon export:
  - `MDP` -> `Main Distribution Panel`
  - `CDP` -> `Central Distribution Panel`
  - `SPL` -> `Splitter`
  - `MCC` -> `Motor Control Center`
  - `PNL` -> `Panel`
  - `SWBD` -> `Switchboard`
  - `ATS` -> `Automatic Transfer Switch`
  - `TX` -> `Transformer`
- SDI package tables now carry `Equipment Type` so the value survives package creation, archive, and retrieval.
- Planon export now reads stored `Equipment Type` first and falls back to parsing `Equipment ID` only when the canonical field is blank.
- The SQLite migration script now backfills `Equipment Type` in `sdi_dataset_EL`, `sdi_print_out`, and `sdi_print_out_arch`.

### Files updated

- `electrical_equipment_rules.py`
- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `SDI_process/app.py`
- `scripts/backfill_amperage_columns_sqlite.py`
- `UBC_Asset_Capture_Application_Technical_Documentation.md`
- `asset_capture_app_dev/.agent/QR_codes_db_schema.md`

### Local migration and validation

- Updated local SQLite DB: `asset_capture_app_dev/data/QR_codes.db`
- Backup created: `asset_capture_app_dev/data/QR_codes.bak_20260401_134004_amperage_columns_migration.db`
- Post-backfill counts:
  - `sdi_dataset_EL`: `176` total, `171` nonblank `Equipment ID`, `163` nonblank `Equipment Type`
  - `sdi_print_out`: `16` total, `0` nonblank `Equipment ID`, `0` nonblank `Equipment Type`
  - `sdi_print_out_arch`: `388` total, `141` nonblank `Equipment ID`, `139` nonblank `Equipment Type`

## 2026-04-01: EL Power Rating capture and DB sync

### Summary

EL extraction now captures `Power Rating` and `Power Rating (UoM)` from the AI output and syncs both fields into `sdi_dataset_EL`.

Update:
- As of `2026-04-11`, EL AI extraction keeps these fields only for transformer tags with explicit proof text.
- Panel assets now save both fields blank.
- See `2026-04-11: EL transformer-only power rating proof rule`.

The intended capture rule is strict:
- the unit must be `KVA`, `KW`, or `VA`
- the unit must be immediately preceded or followed by a whole number
- voltage text such as `600V`, `208Y/120V`, or `600V-208Y/120V` must be ignored

### Implementation notes

- Extended the EL API extraction schema to include:
  - `Power Rating`
  - `Power Rating (UoM)`
- Added shared normalization so inputs like `75KVA`, `75 KVA`, and `KVA 75` normalize to:
  - `Power Rating = 75`
  - `Power Rating (UoM) = KVA`
- Updated the EL extraction prompt to treat image `-1` as the primary source and image `-0` as the fallback source for power rating.
- Updated the EL completeness-guard rescore logic so older EL JSON outputs missing the new fields are treated as stale and can be refreshed on rerun.
- Updated the EL review/save path so `Power Rating` fields are preserved even though they are not yet exposed in the review form.
- Updated EL DB sync so `sdi_dataset_EL` now stores:
  - `Power Rating`
  - `Power Rating (UoM)`

### Files updated

- `API/API_interface_EL_ver00.py`
- `API/validators_shared.py`

## 2026-04-13: EL dashboard attribute-status traffic-light indicator and filter

### Summary

The EL dashboard now shows a traffic-light attribute-status indicator beside each QR code value, based on the required-fields checklist already derived from `sdi_dataset_EL`. The filter area also now includes a custom status filter that uses color balls instead of text labels for the individual status options.

### Rule

- Traffic-light status is derived from the existing EL required-fields checklist:
  - `green`: `0` missing required fields
  - `yellow`: `1` to `2` missing required fields
  - `red`: `3+` missing required fields
- The traffic-light indicator is rendered beside each QR code value.
- The filter control is now labeled `Attribute Status`.
- The filter dropdown options behave as follows:
  - `All Statuses`: text label
  - `Green`: green status ball
  - `Yellow`: yellow status ball
  - `Red`: red status ball
- The yellow palette for this EL status UI uses `#d8f73b`.

### Implementation notes

- The backend checklist payload now includes:
  - `missing_count`
  - `traffic_light`
  - `traffic_light_label`
- The QR-code checklist popover and the inline traffic-light indicator both use the same backend checklist payload so the status logic is not duplicated in the browser.
- Each EL table row stores the normalized traffic-light value in a row attribute so DataTables can filter without parsing icon colors or visible labels.
- The filter uses a custom dropdown UI backed by a hidden select, so the existing client-side filtering, query-string persistence, reset behavior, and review-link propagation continue to work.
- The traffic filter UI is synchronized on:
  - initial page load
  - tab switches
  - filter reset
  - DataTables redraws

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `review/Asset_dashboard_browser_EL/review_asset_templates/dashboard.html`
- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `UBC_Asset_Capture_Application_Technical_Documentation.md`
- `asset_capture_app_dev/.agent/QR_codes_db_schema.md`

### Review UI

- The EL review form now exposes editable fields in the `Technical Details` section for:
  - `Power Rating`
  - `Power Rating (UoM)`
- The form uses the existing field names, so review saves continue to pass through the same normalization logic.
- Inputs like `75KVA`, `75 KVA`, or `75` + `KVA` normalize on save to:
  - `Power Rating = 75`
  - `Power Rating (UoM) = KVA`

### Additional file updated

- `review/Asset_dashboard_browser_EL/review_asset_templates/review.html`

## 2026-04-02: EL Location blank-preserve rule

### Summary

The EL review/dashboard flow no longer auto-fills `Location` from the `UBC Asset Tag` or `Branch Panel` when the field is blank.

### Rule

- If `Location` already has a value, it is kept unless the reviewer edits it.
- If `Location` is blank, it now stays blank.
- The tag dictionary still auto-derives `Volts`, but it no longer backfills `Location`.
- Legacy auto-derived `Location` values are cleared when they exactly match the old tag-derived location, so stored values like `Level 0`, `Level 1`, or `Level 2` do not continue to appear after the rule change.

### Scope

- Review dashboard load
- Review save path
- EL DB sync into `sdi_dataset_EL`

### File updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`

## 2026-04-02: EL explicit-only amperage extraction rule

### Summary

EL AI extraction now keeps `Ampere` only when amperage is explicitly printed in the source image.

Transformer current must no longer be inferred from values like `75KVA`, `600V`, or `208Y/120V`.

### Rule

- `Ampere` must be visibly printed with an amperage unit or amperage label.
- The EL prompt now requires an exact evidence snippet in `Ampere Source Text` during parsing.
- Post-validation keeps the amperage only when that evidence, or OCR context, contains the same whole-number amp value with an amp unit/label.
- If the model only sees transformer specs and calculates a likely current, the saved `Ampere` is cleared.
- Manual review edits are not blocked by this change; the strict rule applies to AI extraction output.

### Related fixes

- Corrected the EL multimodal image labels so the API now treats:
  - `EL-0` as `Asset Plate/Label`
  - `EL-1` as `UBC Asset Tag`
  - `EL-2` as `Panel Schedule`
- OCR context now focuses on `EL-0` and `EL-1`, instead of the old mismatched `EL-1` and `EL-2`.
- Added an EL extraction rule version so older JSON payloads are treated as stale when intentionally rerun.
- Targeted reruns with `--qr <QR_CODE>` now bypass the processed-QR skip, which allows refreshing an existing EL asset after rule changes.

### Files updated

- `API/API_interface_EL_ver00.py`
- `API/validators_shared.py`

## 2026-04-02: EL transformer volts normalization

### Summary

EL voltage normalization now preserves transformer primary-secondary notation instead of collapsing it to the first voltage token.

### Rule

- Transformer-style values are now normalized to the full primary-secondary format:
  - `600V-208Y/120V` -> `600V-208Y/120V`
  - `600-208Y/120V` -> `600V-208Y/120V`
  - `600 DELTA-208Y/120V` -> `600V-208Y/120V`
  - `600 DELTA 208Y/120V` -> `600V-208Y/120V`
- Secondary-only Wye notation is also preserved:
  - `208Y/120V` -> `208Y/120V`
- Existing panel notation remains unchanged:
  - `208/120V`
  - `480/277V`
  - `600/347V`

### Related notes

- The EL extraction prompt now explicitly allows transformer voltage notation like `600V-208Y/120V`.
- The EL extraction rule version was bumped so targeted reruns can refresh older transformer JSON payloads that were previously normalized to `600V`.

### Files updated

- `API/API_interface_EL_ver00.py`
- `API/validators_shared.py`

## 2026-04-02: EL `Fed From Amperage Rating` DB-derived mapping

### Summary

`Fed From Amperage Rating` is now derived from curated EL data already stored in `sdi_dataset_EL` and is no longer left unmapped.

### Rule

- For each EL row, use:
  - same `Building`
  - current row `Supply From`
  - match against another EL row `UBC Asset Tag`
- If a match is found:
  - copy the matched row `Amperage Rating` into `Fed From Amperage Rating`
- If no match is found:
  - keep `Fed From Amperage Rating` blank

### Scope

- EL DB sync in `sdi_dataset_EL`
- EL historical backfill in `sdi_dataset_EL`
- SDI package tables:
  - `sdi_print_out`
  - `sdi_print_out_arch`
- Planon export/template fill from the stored field

### Related notes

- The lookup is exact after trim/case normalization.
- Matching is restricted to the same building.
- The SDI export now carries the stored `Fed From Amperage Rating` field directly; it is no longer something that would need to be recomputed at the final spreadsheet step.
- The SQLite migration script now backfills this field for existing databases as well.

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `SDI_process/app.py`
- `scripts/backfill_amperage_columns_sqlite.py`

## 2026-04-07: EL `Voltage Rating` source-of-truth shift

### Summary

`Voltage Rating` is now the canonical stored EL voltage field for SDI export. The legacy `Volts` field remains as a compatibility mirror during the transition.

### Rule

- EL sync resolves voltage using the current volts logic:
  - start from structured `Volts`
  - keep the current dictionary/tag volts override unchanged
- The resolved value is dual-written to:
  - `Voltage Rating`
  - `Volts`
- `Voltage Rating (UoM)` is stored as:
  - `VLT` when `Voltage Rating` is nonblank
  - blank otherwise

### Scope

- EL DB sync in `sdi_dataset_EL`
- EL historical backfill in `sdi_dataset_EL`
- SDI package tables:
  - `sdi_print_out`
  - `sdi_print_out_arch`
- Planon export/template fill from stored:
  - `Voltage Rating`
  - `Voltage Rating (UoM)`

### Related notes

- SDI now prefers stored `Voltage Rating` and only falls back to `Volts` for legacy blanks.
- The SQLite migration script now ensures and backfills both voltage columns in EL and package tables.
- `Volts` is still preserved as a compatibility mirror and is not removed in this phase.

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `SDI_process/app.py`
- `scripts/backfill_amperage_columns_sqlite.py`

## 2026-04-09: EL `Fed From Equipment ID` canonical shift

### Summary

`Fed From Equipment ID` is now the canonical stored/export field for the EL upstream source identifier. `Supply From` remains the editable EL working field and compatibility source during the transition.

### Rule

- EL sync derives:
  - `Fed From Equipment ID = Supply From`
- EL DB sync stores both:
  - `Supply From`
  - `Fed From Equipment ID`
- SDI export now prefers stored `Fed From Equipment ID`
- Legacy fallback remains:
  - if `Fed From Equipment ID` is blank, use `Supply From`

### Scope

- EL DB sync in `sdi_dataset_EL`
- EL historical backfill in `sdi_dataset_EL`
- SDI package tables:
  - `sdi_print_out`
  - `sdi_print_out_arch`
- Planon export/template fill from stored `Fed From Equipment ID`

### Related notes

- `Supply From` is not removed in this phase.
- `Fed From Amperage Rating` logic remains based on `Supply From`.
- No EL review UI rename is included in this phase.
- The SQLite migration script now ensures and backfills `Fed From Equipment ID` in EL and package tables.

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `SDI_process/app.py`
- `scripts/backfill_amperage_columns_sqlite.py`

## 2026-04-09: EL tag, location, and panel-voltage extraction hardening

### Summary

The EL API now applies stricter source rules for `UBC Asset Tag`, `Location`, and panel `Volts` so panel outputs are derived from the intended image/source instead of nearby QR labels or warning text.

### Rule

- `UBC Asset Tag` must come from the printed panel identifier, not the blue `Asset Identification` QR sticker or its long numeric code.
- `Location` is EL-2-only and is accepted only when EL-2 shows an explicit labeled header such as:
  - `Location:`
  - `Room:`
  - `Space:`
  - `Area:`
  - `Level:`
  - `Floor:`
- Panel `Volts` now prefer the dictionary voltage code carried in the finalized `UBC Asset Tag`:
  - voltage code `2` -> `208/120V`
  - voltage code `6` -> `600/347V`
- If the finalized tag does not expose a recognized panel voltage code, the EL API keeps the AI-captured `Volts` value.

### Implementation notes

- Added EL post-processing so QR-like numeric identifiers are rejected for `UBC Asset Tag` and the printed panel tag is preferred.
- Added a seq-2 reread path for `Location` with internal `Location Source Text` validation.
- Panel-name fragments such as `NRM1` are no longer accepted as `Location`.
- Dictionary-derived panel voltage now overrides AI voltage when a recognized panel prefix and leading voltage code are present in the finalized tag.
- Older EL JSON outputs are treated as stale when stored `Volts` do not match the current dictionary-derived panel voltage.

### Files updated

- `API/API_interface_EL_ver00.py`
- `API/validators_shared.py`
- `dictionary/electrical.dictionary.py`

## 2026-04-10: EL OCR resilience and amperage alignment

### Summary

EL OCR now handles upside-down EL plates more reliably, and EL amperage post-processing stays aligned with the saved value.

### Rule

- When OCR is enabled for EL assets, the API now tries both:
  - original image orientation
  - 180-degree rotated orientation
- The stronger OCR result is used as the EL OCR context.
- When `EL_HYBRID_OCR_AGENT` is not explicitly set, OCR now runs by default whenever `EL_OCR_MODE` is not `off`.
- Valid panel amperage values like `225A` are no longer dropped because they exceed an old numeric ceiling.
- If the saved `Ampere` field is blank, EL confidence for `Ampere` is forced to `0`.

### Implementation notes

- Added OCR scoring/orientation selection for EL-0 and EL-1.
- This specifically improves panelboard plate reads where the plate photo is upside down.
- The OCR/default-runtime change applies only to the EL API extraction path; no EL review JSON schema changes were introduced.

### Files updated

- `API/API_interface_EL_ver00.py`

## 2026-04-11: EL transformer-only power rating proof rule

### Summary

EL `Power Rating` capture is now transformer-only and requires explicit proof text. This supersedes the earlier broad EL AI power-rating capture rule for panel assets.

### Rule

- Only transformer-style EL tags such as `TX-*` may keep:
  - `Power Rating`
  - `Power Rating (UoM)`
- Panel tags such as `PNL-*`, `CDP-*`, `MDP-*`, `MCC-*`, `ATS-*`, and `SPL-*` now save both fields blank.
- Valid transformer power-rating evidence must be an explicit positive whole-number adjacency pattern such as:
  - `75 KVA`
  - `KVA 75`
  - `15 KW`
  - `500 VA`
- Decimal/malformed voltage-adjacent text must not populate power rating, including:
  - `0.208 kVac`
  - `VAC`
  - `208Y/120V`
  - `600/347V`
  - `600V-208Y/120V`

### Implementation notes

- Added internal `Power Rating Source Text` to the EL AI extraction schema for proof validation.
- Transformer power rating is now validated against explicit source text first, with OCR context used as secondary support.
- Non-transformer EL outputs are now treated as stale when stored power-rating fields are nonblank.
- EL extraction rule version is now `14`.

### Files updated

- `API/API_interface_EL_ver00.py`
- `API/validators_shared.py`

## 2026-04-12: EL dashboard QR required-fields hover checklist

### Summary

The EL dashboard now shows a read-only required-fields checklist when users hover or focus the QR code value. The checklist is sourced directly from `sdi_dataset_EL` at page render time and indicates whether each required field is filled or blank for the current EL asset.

### Rule

- Every EL asset group checks `UBC Asset Tag`.
- Additional checks are applied by stored `Asset Group` from `sdi_dataset_EL`:
  - `Interior Distribution Transformers`:
    - `Power Rating`
    - `Power Rating (UoM)`
    - `Voltage Rating`
    - `Voltage Rating (UoM)`
    - `Equipment ID`
    - `Equipment Type`
    - `Fed From Amperage Rating`
    - `Fed From Amperage Rating (UoM)`
    - `Fed From Equipment ID`
    - `Power Type`
  - `Panels`:
    - `Amperage Rating`
    - `Amperage Rating (UoM)`
    - `Equipment ID`
    - `Voltage Rating`
    - `Voltage Rating (UoM)`
    - `Supply From`
    - `Equipment Type`
    - `Fed From Amperage Rating`
    - `Fed From Amperage Rating (UoM)`
    - `Fed From Equipment ID`
    - `Power Type`
  - `Other Service and Distribution`:
    - `Amperage Rating`
    - `Amperage Rating (UoM)`
    - `Equipment ID`
    - `Equipment Type`
    - `Fed From Equipment ID`
    - `Power Type`
    - `Voltage Rating`
    - `Voltage Rating (UoM)`
  - `Motor Control Centers`:
    - `Amperage Rating`
    - `Amperage Rating (UoM)`
    - `Equipment ID`
    - `Equipment Type`
    - `Fed From Amperage Rating`
    - `Fed From Amperage Rating (UoM)`
    - `Fed From Equipment ID`
    - `Power Type`
    - `Voltage Rating`
    - `Voltage Rating (UoM)`
  - `Automatic Transfer Switches`:
    - `Amperage Rating`
    - `Amperage Rating (UoM)`
    - `Equipment ID`
    - `Equipment Type`
    - `Fed From Amperage Rating`
    - `Fed From Equipment ID`
    - `Power Type`
    - `Voltage Rating`
    - `Voltage Rating (UoM)`
- A field is marked filled only when the stored `sdi_dataset_EL` value is not `NULL`, not empty, and not whitespace after trimming.
- Asset groups without an explicit checklist rule currently show only the universal `UBC Asset Tag` check.

### Implementation notes

- The EL dashboard now bulk-reads the required checklist columns from `sdi_dataset_EL` once per page render for all visible QR codes.
- The checklist payload is attached to each rendered EL row before `dashboard.html` is built.
- The QR code cell is now the hover/focus trigger and opens a Bootstrap popover.
- Each checklist line shows:
  - green `check-circle` when the field is filled
  - red `x-circle` when the field is blank
- If no matching `sdi_dataset_EL` row exists for a QR, the popover still opens, shows a short missing-row note, and marks the universal `UBC Asset Tag` check as missing.
- Popovers are re-initialized after DataTables redraws so the checklist keeps working after sort, filter, or pagination changes.

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `review/Asset_dashboard_browser_EL/review_asset_templates/dashboard.html`

## 2026-04-13: EL `Supply From` upstream-ID normalization

### Summary

EL `Supply From` extraction now keeps the upstream equipment identifier only, instead of saving the full descriptive phrase from the label.

### Rule

- `Supply From` is normalized from EL `Fed`, `Fed From`, or `Supply From` text.
- The normalized value should be the upstream equipment identifier only.
- Examples:
  - `FED FROM MDC IN MAIN ELEC. RM` -> `MDC`
  - `CDP-2N1 FED FROM MDC IN MAIN ELEC. RM` -> `MDC`
  - `FED FROM PANEL 2N0D1` -> `2N0D1`
  - `FED FROM CDP 2N1` -> `CDP-2N1`
  - `FROM TX-N0N1` -> `TX-N0N1`
- Generic descriptive words such as `PANEL`, `PANELBOARD`, `ROOM`, `RM`, `SPACE`, `AREA`, `LEVEL`, `FLOOR`, `MAIN`, and `ELEC` are not preserved as the final `Supply From` value.
- When a real equipment prefix is part of the upstream identifier, it is preserved.

### Implementation notes

- Tightened the shared `normalize_supply_from()` rule so it:
  - anchors to the `FED FROM` / `FROM` phrase when present anywhere in the captured text
  - strips trailing room/location wording
  - converts common equipment phrases into a canonical upstream identifier
- Updated the EL extraction prompt so the model is instructed to return only the upstream equipment identifier for `Fed` / `Fed From`.
- EL extraction rule version is now `15`, so older EL JSON outputs are treated as stale on rerun.

### Files updated

- `API/API_interface_EL_ver00.py`
- `API/validators_shared.py`

## 2026-04-13: EL `Fed From Amperage Rating` blank-clear rule and live refresh

### Summary

`Fed From Amperage Rating` and `Fed From Amperage Rating (UoM)` are now cleared whenever `Supply From` is blank, so stale upstream values do not remain attached to EL rows or SDI package rows. The EL review form also now refreshes the derived `Fed From` values immediately when reviewers change `Supply From`.

### Rule

- If `Supply From` is blank:
  - set `Fed From Amperage Rating` blank
  - set `Fed From Amperage Rating (UoM)` blank
- If `Supply From` has a value:
  - derive `Fed From Amperage Rating` from the same-building `UBC Asset Tag` match
  - derive `Fed From Amperage Rating (UoM)` from the resolved amperage value
- The EL review form now re-runs the upstream lookup on `Supply From` change so the displayed `Fed From` values stay aligned before save.

### Scope

- EL derived-field cleanup/backfill in `sdi_dataset_EL`
- SDI package tables:
  - `sdi_print_out`
  - `sdi_print_out_arch`
- EL review form live refresh for derived `Fed From` values

### Implementation notes

- The EL and SDI backfill paths now skip the upstream lookup when `Supply From` is blank instead of leaving older derived amperage values in place.
- Existing rows with blank `Supply From` now have stale `Fed From Amperage Rating` and `Fed From Amperage Rating (UoM)` cleared.
- Added an authenticated EL lookup endpoint for the review UI:
  - `/api/fed_from_lookup/<building>/<supply_from>`
- The review form uses that endpoint on `Supply From` change to refresh:
  - `Fed From Amperage Rating`
  - `Fed From Amperage Rating (UoM)`

### Files updated

- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py`
- `review/Asset_dashboard_browser_EL/review_asset_templates/review.html`
- `SDI_process/app.py`
- `run_db_cleanup.py`

## 2026-05-14: Review-app listing-page column visibility trim

### Summary

Each Review-app listing page ("Asset Review Dashboard - Mechanical / Backflow / Electrical") now hides a fixed set of nameplate columns from the New / Update / Manual tab tables. This is a presentation-only change — no schema, JSON, SDI, Planon, AI, or audit-trail behavior is affected.

### Columns hidden on the listing tables

- **ME** — `Manufacturer`, `Model`, `Serial Number`, `Technical Safety BC` (DataTables column indices 6, 7, 8, 10).
- **BF** — `Type`, `Model`, `Serial Number` (indices 5, 7, 8).
- **EL** — `Amperage Rating`, `Volts`, `Location` (indices 7, 8, 9).

### Scope of change

- Applies to `review_asset_templates/dashboard.html` in each of the three review apps, on all three table tabs (New / Update / Manual) and in both standalone and Dashboard-portal-embedded contexts.
- The per-asset review page (`review.html`, opened via the per-row Review button) is intentionally untouched — reviewers still see every field when editing a single asset.
- All downstream consumers (`sdi_dataset`, `sdi_dataset_EL`, `sdi_print_out`, Planon export, AI extraction, audit trail, dashboard KPIs) continue to carry the full field set.

### Implementation notes

- Each `initAssetTable(...)` `DataTable({...})` config gains an `initComplete` callback:
  ```javascript
  initComplete: function () {
      this.api().columns([/* hidden indices */]).visible(false);
  }
  ```
- The `initComplete` path is used (rather than `columnDefs.visible: false`) so the hide reliably overrides any restored `stateSave` visibility from prior sessions where the columns were shown.
- The hide is unconditional. An earlier attempt gated it on `{% if g.embedded %}` (server-side) and on `window.self !== window.top` (client-side); both were dropped after the user confirmed they want the columns hidden everywhere the listing table is shown.
- Related auth-flow note: the review apps' `login.html` form action does not preserve the `next` query parameter on POST, so any URL-flag-gated server-side approach would fail after a fresh-login redirect anyway. See `rules/review_apps.rules.md` "Known auth-flow gotcha".

### Files updated

- `review/Asset_dasboard_browser_ME/review_asset_templates/dashboard.html`
- `review/Asset_dasboard_browser_BF/review_asset_templates/dashboard.html`
- `review/Asset_dashboard_browser_EL/review_asset_templates/dashboard.html`
- `Markdowns_documentation/rules/review_apps.rules.md` (new "Listing-Page Column Visibility Rules" section + "Known auth-flow gotcha" subsection)

## 2026-05-14: Review-app Avg AI Conf gauge + new Comp Score column

### Summary

The "Avg AI Conf" column on the review-app listing tables (ME, BF, EL) now renders as a green gradient capsule gauge with a triangle marker at the row's percentage and the numeric value below, replacing the prior single-tone pill and earlier five-color segmented bar. A new **"Comp Score"** column is inserted immediately after Avg AI Conf, rendering the same gauge but sourced from each asset's completeness score. No schema, JSON, SDI, Planon, AI extraction, or audit-trail behavior is affected -- both fields already existed; only the rendering and the column slot are new.

### Avg AI Conf gauge

- Same data source as before (`Avg_ai_conf` on the item dict, populated from `_normalize_avg_ai_conf(_extract_avg_ai_conf(raw))`).
- Visualization changed from a single colored pill (low / medium / high based on `<70`, `70-80`, `>=80`) to a bordered green capsule gauge with a triangle marker at the row's percentage.
- The capsule uses `linear-gradient(to right, #dcfce7 0%, #16a34a 100%)`, so higher percentages sit farther into the darker green side.
- The capsule has `border: 1px solid rgba(21, 128, 61, 0.45)` and `box-sizing: border-box` to keep the border inside the 12px bar height.
- The legacy `.avg-ai-conf-pill` CSS rules remain in each `dashboard.html` (orphaned, no markup references them anymore). They are a candidate for a later cleanup pass.

### Comp Score column

- New column inserted immediately after "Avg AI Conf" on the listing tables of all three review apps.
- Header label: `Comp Score`.
- Value pulled from `raw["completeness_score"]` (the top-level field that `API/API_interface_*_ver00.py` writes during AI extraction).
- Normalized through the existing `_normalize_avg_ai_conf()` helper (reused as a generic 0-100 → "XX,YY%" formatter, despite its name).
- Renders with the same bordered green capsule gauge component as Avg AI Conf.
- For assets whose JSON predates the completeness writeback, the cell shows `N/A`; re-running `./run_ai_and_sync.sh <discipline> <qr_code>` populates the field.

### DataTables column-index impact

The Comp Score insertion shifted indices for every column AFTER Avg AI Conf. Updated index variables in each `dashboard.html`:

- **ME**: `colApproved` 17 → 18; `colAction` 19 → 20.
- **BF**: `colApproved` 16 → 17; `colAction` 18 → 19.
- **EL**: `colAssetGroup` 12 → 13; `colApproved` 14 → 15; `colAction` 16 → 17.

The hidden-column index lists from the listing-page column-visibility rule are all BEFORE the new column (`[6, 7, 8, 10]` for ME, `[5, 7, 8]` for BF, `[7, 8, 9]` for EL) and were left unchanged.

### Files updated

- `review/Asset_dasboard_browser_ME/asset_plate_reviewer.py` (item dict gains `Comp_score` / `Comp_score_display`)
- `review/Asset_dasboard_browser_BF/asset_plate_reviewer_bf.py` (same)
- `review/Asset_dashboard_browser_EL/Asset_dashboard_EL.py` (same)
- `review/Asset_dasboard_browser_ME/review_asset_templates/dashboard.html` (green gradient capsule CSS + border + new `<th>` and `<td>` per tab + index bumps)
- `review/Asset_dasboard_browser_BF/review_asset_templates/dashboard.html` (same)
- `review/Asset_dashboard_browser_EL/review_asset_templates/dashboard.html` (same)
- `Markdowns_documentation/rules/review_apps.rules.md` (new "Confidence and Completeness Gauge Rules" section)
